#pragma once
#include "Entities.h"

class Boss : public Entities
{
public:
	void moveX(int MoveX, int MagnitudeX);
	void moveY(int MoveY, int MagnitudeY);
	int BossXCheck(int x1, int x2);
	int BossYCheck(int y1, int y2);
	void setXandY(int NewX, int NewY);
	Boss();
	~Boss();
};

