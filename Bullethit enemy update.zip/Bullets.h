#pragma once
class Bullets
{
private:
    int oldx, oldy, bulletdirection;
    char Symbol;
public:
    void setOldPosition(int x, int y);
    void setBulletSymbol(int x); //1 is vertical, 2 is horizontal
    void setBulletDirection(int x); //1 is up, 2 is down, 3 is left, 4 is right
    int getOldX();
    int getOldy();
    char getSymbol();
    int getBulletDIrection();

    ~Bullets();
};