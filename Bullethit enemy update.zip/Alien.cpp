#include "Alien.h"

Alien::Alien()
{
	character = (char)254;
	health = 3;
}
