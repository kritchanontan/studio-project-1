#pragma once
#include "Entities.h"

class Alien : public Entities
{
public:
	Alien();
};

