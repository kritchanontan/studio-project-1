#include <iostream>
#include "Map.h"
#include <Windows.h>
#include "Entities.h"
#include "Player.h"
#include "Alien.h"
#include "GameMenu.h"
#include <conio.h>
using namespace std;

int main() {
	//srand((unsigned)time(NULL));
	//HWND console = GetConsoleWindow();
	//RECT r;
	//GetWindowRect(console, &r); //stores the console's current dimensions

	//MoveWindow(console, r.left, r.top, 328, 390, TRUE); // 800 width, 100 height


	//bool keyboardBoardPressedOnce = true;
	Entities* myGameObject[3] = { nullptr, nullptr };
	GameMenu Menu;
	Menu.GameIntro();
	system("cls");
	int MagnitudeX, MagnitudeY;
	int GhostMagnitudeX, GhostMagnitudeY;

	Map* map = new Map;
	Player SpaceShip;
	Alien aliens;
	myGameObject[0] = &SpaceShip;
	myGameObject[1] = &aliens;
	myGameObject[1]->setXandY((rand() % 39) + 1, (rand() % 39) + 1);
	map->UpdatedMap();

	while (true) {
		MagnitudeX = 0;
		MagnitudeY = 0;
		GhostMagnitudeX = (rand() % 3) - 1;
		GhostMagnitudeY = (rand() % 3) - 1;

		if (GetAsyncKeyState(VK_UP)) {
			MagnitudeY = -1;
		}
		if (GetAsyncKeyState(VK_DOWN)) {
			MagnitudeY = 1;
		}
		if (GetAsyncKeyState(VK_RIGHT)) {
			MagnitudeX = 1;
		}
		if (GetAsyncKeyState(VK_LEFT)) {
			MagnitudeX = -1;
		}

		Sleep(60);
		myGameObject[0]->moveX(myGameObject[0]->GetX(), MagnitudeX);
		myGameObject[0]->moveY(myGameObject[0]->GetY(), MagnitudeY);
		map->DrawEntities(myGameObject[0]->GetX(), myGameObject[0]->GetY(), MagnitudeX, MagnitudeY, myGameObject[0]->GetName());

		//myGameObject[1]->moveX(myGameObject[1]->GetX(), GhostMagnitudeX);
		//myGameObject[1]->moveY(myGameObject[1]->GetY(), GhostMagnitudeY);
		//map->DrawEntities(myGameObject[1]->GetX(), myGameObject[1]->GetY(), GhostMagnitudeX, GhostMagnitudeY, myGameObject[1]->GetName());
	}
	delete map;
	return 0;
}