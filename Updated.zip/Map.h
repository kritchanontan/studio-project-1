#pragma once

class Map
{
private:
	char MapSize[21][41];
public:
	void UpdatedMap();
	void DrawEntities(int x, int y, int MagnitudeX, int MagnitudeY, char name);
};

