#pragma once
#include "Entities.h"

class Enemy : public Entities
{
private:
	int health;
public:
	void moveX(int MoveX, int MagnitudeX);
	void moveY(int MoveY, int MagnitudeY);
	void setXandY(int NewX, int NewY);
	Enemy();
};

