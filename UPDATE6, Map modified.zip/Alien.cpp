#include "Alien.h"

Alien::Alien()
{
	character = 'A';
}
