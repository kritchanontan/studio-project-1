#pragma once

class Map
{
private:
	char MapSize[21][41];
public:
	void SetMapC3Normal();
	void SetMapC2();
	void SetMapC4();
	void SetMapB3_D3();
	void SetMapD4();
	void SetMapD5();
	void SetMapE1();
	void SetMapE2();
	void SetMapE3();
	void SetMapE4();
	void SetMapE5();
	void SpawnMap();
	bool CollisionX(int PosX, int PosY, int MagnitudeX, char name);
	bool CollisionY(int PosX, int PosY, int MagnitudeY, char name);
	void DrawEntities(int x, int y, int MagnitudeX, int MagnitudeY, char name);
};

