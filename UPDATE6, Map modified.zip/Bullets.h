#pragma once

class Bullets
{
private:
    int oldx, oldy, newx, newy, bulletdirection;
    char Symbol;
public:
    void setOldPosition(int x, int y);
    void setNewPosition(int x, int y);
    void setBulletSymbol(int x); //1 is vertical, 2 is horizontal
    void setBulletDirection(int x);
    int getOldX();
    int getOldy();
    int getNewX();
    int getNewY();
    char getSymbol();
};