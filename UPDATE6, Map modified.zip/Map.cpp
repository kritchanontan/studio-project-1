#include "Map.h"
#include <iostream>
using namespace std;

void Map::SetMapC3Normal()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 1 and j >= 0 and j <= 14)
				MapSize[i][j] = '#';
			if (i >= 0 and i <= 1 and j >= 26 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 18 and i <= 19 and j >= 0 and j <= 14)
				MapSize[i][j] = '#';
			if (i >= 18 and i <= 19 and j >= 26 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 2 and i <= 7 and j >= 0 and j <= 4)
				MapSize[i][j] = '#';
			if (i >= 12 and i <= 17 and j >= 0 and j <= 4)
				MapSize[i][j] = '#';
			if (i >= 2 and i <= 7 and j >= 36 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 12 and i <= 17 and j >= 36 and j <= 40)
				MapSize[i][j] = '#';

		}
	}
}

void Map::SetMapC2()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = '#';
			if (i >= 8 and i <= 11 and j >= 0 and j <= 40)
				MapSize[i][j] = ' ';
		}
	}
}

void Map::SetMapC4()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = '#';
			if (i >= 8 and i <= 11 and j >= 0 and j <= 40)
				MapSize[i][j] = ' ';
		}
	}
}

void Map::SetMapB3_D3() {
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 1 and j >= 0 and j < 15)
				MapSize[i][j] = '#';
			if (i >= 0 and i <= 1 and j >= 26 and j <= 40)
				MapSize[i][j] = '#';

			if (i >= 18 and i <= 19 and j >= 0 and j < 15)
				MapSize[i][j] = '#';
			if (i >= 18 and i <= 19 and j >= 26 and j <= 40)
				MapSize[i][j] = '#';

			if (i >= 5 and i <= 7 and j >= 4 and j <= 8)
				MapSize[i][j] = '#';
			if (i >= 12 and i <= 14 and j >= 4 and j <= 8)
				MapSize[i][j] = '#';
			if (i >= 5 and i <= 7 and j > 17 and j < 23)
				MapSize[i][j] = '#';
			if (i >= 12 and i <= 14 and j > 17 and j < 23)
				MapSize[i][j] = '#';
			if (i >= 5 and i <= 7 and j > 31 and j <= 36)
				MapSize[i][j] = '#';
			if (i >= 12 and i <= 14 and j > 31 and j <= 36)
				MapSize[i][j] = '#';
		}
	}
}

void Map::SetMapD4()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 1 and j >= 0 and j <= 40)
				MapSize[i][j] = (char)176;
			if (i >= 18 and i <= 19 and j >= 0 and j <= 4)
				MapSize[i][j] = (char)176;
			if (i >= 12 and i <= 19 and j >= 26 and j <= 40)
				MapSize[i][j] = (char)176;
		}
	}
}

void Map::SetMapD5()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 1 and j >= 0 and j <= 34)
				MapSize[i][j] = (char)176;
			if (i >= 0 and i <= 19 and j >= 39 and j <= 40)
				MapSize[i][j] = (char)176;
			if (i >= 12 and i <= 19 and j >= 0 and j < 15)
				MapSize[i][j] = (char)176;
		}
	}
}

void Map::SetMapE1()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 18 and i < 20 and j >= 0 and j <= 40) {
				MapSize[i][j] = '#';
			}
			if (i >= 0 and i < 20 and j >= 0 and j < 2) {
				MapSize[i][j] = '#';
			}

			if (i >= 0 and i <= 7 and j >= 25  and j <= 40) {
				MapSize[i][j] = '#';
			}

			if (i == 2 and j >= 25 and j <= 26) {
				MapSize[i][j] = ' ';
			}

			if (i == 3 and j >= 25 and j <= 27) {
				MapSize[i][j] = ' ';
			}
			if (i == 4 and j >= 25 and j <= 31) {
				MapSize[i][j] = ' ';
			}
			if (i == 5 and j >= 25 and j <= 35) {
				MapSize[i][j] = ' ';
			}
			if (i == 6 and j >= 25 and j <= 37) {
				MapSize[i][j] = ' ';
			}
			if (i == 7 and j >= 25 and j <= 38) {
				MapSize[i][j] = ' ';
			}
		}
	}
}

void Map::SetMapE2()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';

			if (i >= 18 and i < 20 and j >= 0 and j <= 40) {
				MapSize[i][j] = '#';
			}


			if (i >= 0 and i <= 1 and j >= 0 and j <= 40) {
				MapSize[i][j] = '#';
			}

			if (i == 2 and j >= 0 and j <= 40) {
				MapSize[i][j] = '#';
				for (int j = 14; j <= 26; j++) {
					MapSize[i][j] = ' ';
				}
			}

			if (i == 3 and j >= 0 and j <= 40) {
				MapSize[i][j] = '#';
				for (int j = 13; j <= 27; j++) {
					MapSize[i][j] = ' ';
				}
			}

			if (i == 4 and j >= 0 and j <= 40) {
				MapSize[i][j] = '#';
				for (int j = 9; j <= 31; j++) {
					MapSize[i][j] = ' ';
				}
			}

			if (i == 5 and j >= 0 and j <= 40) {
				MapSize[i][j] = '#';
				for (int j = 5; j <= 35; j++) {
					MapSize[i][j] = ' ';
				}
			}

			if (i == 6 and j >= 0 and j <= 40) {
				MapSize[i][j] = '#';
				for (int j = 3; j <= 37; j++) {
					MapSize[i][j] = ' ';
				}
			}

			if (i == 7 and j >= 0 and j <= 40) {
				MapSize[i][j] = '#';
				for (int j = 2; j <= 38; j++) {
					MapSize[i][j] = ' ';
				}
			}

			for (int i = 0; i < 9; i++) {
				for (int j = 16; j < 25; j++) {
					MapSize[i][j] = ' ';
				}
			}
		}
		cout << endl;
	}
}

void Map::SetMapE3()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';

			if (i >= 18 and i < 20 and j >= 0 and j <= 40) {
				MapSize[i][j] = '#';
			}
			if (i >= 0 and i < 5 and j >= 0 and j <= 40) {
				MapSize[i][j] = '#';
			}
			for (int i = 0; i < 9; i++) {
				for (int j = 15; j <= 25; j++) {
					MapSize[i][j] = ' ';
				}
			}

			if (i >= 5 and i < 8 and j >= 0 and j <= 40) {
				MapSize[i][j] = '#';
			}

			for (int i = 4; i <= 8; i++) {
				for (int j = 5; j <= 35; j++) {
					MapSize[i][j] = ' ';
				}
			}

			for (int i = 15; i < 25; i++) {
				MapSize[0][i] = ' ';
			}
		}
		cout << endl;
	}
}

void Map::SetMapE4()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';

			if (i >= 18 and i < 20 and j >= 0 and j <= 40) {
				MapSize[i][j] = (char)176;
			}

			if (i >= 0 and i < 8 and j >= 0 and j <= 40) {
				MapSize[i][j] = (char)176;
			}

			for (int i = 0; i <= 8; i++) {
				for (int j = 5; j <= 25; j++) {
					MapSize[i][j] = ' ';
				}
			}


		}
	}
}


void Map::SetMapE5()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';

			if (i >= 18 and i < 20 and j >= 0 and j <= 40) {
				MapSize[i][j] = (char)176;
			}

			if (i >= 0 and i < 8 and j >= 0 and j < 15) {
				MapSize[i][j] = (char)176;
			}

			if (i >= 0 and i < 20 and j > 38 and j <= 40) {
				MapSize[i][j] = (char)176;
			}
		}
	}
}


//Map1
void Map::SpawnMap()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			cout << MapSize[i][j];
		}
		cout << endl;
	}
}

bool Map::CollisionX(int PosX, int PosY, int MagnitudeX, char name)
{
	if (MagnitudeX == -1) {
		if (MapSize[PosY][PosX - 1] == '#' or MapSize[PosY][PosX - 1] == (char)176) {
			return true;
		}
	}
	if (MagnitudeX == 1) {
		if (MapSize[PosY][PosX + 1] == '#' or MapSize[PosY][PosX + 1] == (char)176) {
			return true;
		}
	}
	return false;
}

bool Map::CollisionY(int PosX, int PosY, int MagnitudeY, char name)
{
	if (MagnitudeY == -1) {
		if (MapSize[PosY - 1][PosX] == '#' or MapSize[PosY - 1][PosX] == (char)176) {
			return true;
		}
	}
	if (MagnitudeY == 1) {
		if (MapSize[PosY + 1][PosX] == '#' or MapSize[PosY + 1][PosX] == (char)176) {
			return true;
		}
	}
	return false;
}

void Map::DrawEntities(int PosX, int PosY, int MagnitudeX, int MagnitudeY, char name)
{ 
	// Spawn Entities
	MapSize[PosY][PosX] = name;

	// Left Arrow Movement
	if (MagnitudeX == -1) {
		MapSize[PosY][PosX + 1] = ' ';
	}

	// Right Arrow Movement
	if (MagnitudeX == 1) {
		MapSize[PosY][PosX - 1] = ' ';
	}

	// Up Arrow Movement
	if (MagnitudeY == -1) {
		MapSize[PosY + 1][PosX] = ' ';
	}

	// Down Arrow Movement
	if (MagnitudeY == 1) {
		MapSize[PosY - 1][PosX] = ' ';
	}

	//Up and right arrow
	if (MagnitudeX == 1 and MagnitudeY == -1) {
		MapSize[PosY + 1][PosX - 1] = ' ';
	}

	// Down and left arrow
	if (MagnitudeX == -1 and MagnitudeY == 1) {
		MapSize[PosY - 1][PosX + 1] = ' ';
	}

	// down and right arrow
	if (MagnitudeX == 1 and MagnitudeY == 1) {
		MapSize[PosY - 1][PosX - 1] = ' ';
	}

	// Up and left arrow
	if (MagnitudeX == -1 and MagnitudeY == -1) {
		MapSize[PosY + 1][PosX + 1] = ' ';
	}
}
