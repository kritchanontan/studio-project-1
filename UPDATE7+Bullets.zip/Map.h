#pragma once

class Map
{
private:
	char MapSize[21][41];
public:
	void SetMapA1();
	void SetMapA2();
	void SetMapA3();
	void SetMapA4();
	void SetMapA5();
	void SetMapB1();
	void SetMapB2();
	void SetMapB3();
	void SetMapB4();
	void SetMapB5();
	void SetMapC1();
	void SetMapC2();
	void SetMapC3Normal();
	void SetMapC4();
	void SetMapC5();
	void SetMapD1();
	void SetMapD2();
	void SetMapD3();
	void SetMapD4();
	void SetMapD5();
	void SetMapE1();
	void SetMapE2();
	void SetMapE3();
	void SetMapE4();
	void SetMapE5();
	void SpawnMap();
	bool CollisionX(int PosX, int PosY, int MagnitudeX, char name);
	bool CollisionY(int PosX, int PosY, int MagnitudeY, char name);
	void DrawEntities(int x, int y, int MagnitudeX, int MagnitudeY, char name);
	int BulletCollisionX(int PosX, int PosY, int MagnitudeX, char name); //check for bullet collision ( 0 = empty, 1 = '#,
	int BulletCollisionY(int PosX, int PosY, int MagnitudeY, char name); //check for bullet collision ( 0 = empty, 1 = '#,
	int CheckMap(int x, int y);
};

