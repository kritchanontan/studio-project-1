﻿#include <iostream>
#include "Map.h"
#include <windows.h>
#include "Entities.h"
#include "Player.h"
#include "Alien.h"
#include "GameMenu.h"
#include "Bullets.h"
#pragma comment(lib,"Winmm.lib")
using namespace std;

void clearScreen()
{
	HANDLE hOut;
	COORD Position;

	hOut = GetStdHandle(STD_OUTPUT_HANDLE);

	Position.X = 0;
	Position.Y = 0;
	SetConsoleCursorPosition(hOut, Position);
}

void ShowConsoleCursor(bool showFlag)
{
	HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);

	CONSOLE_CURSOR_INFO     cursorInfo;

	GetConsoleCursorInfo(out, &cursorInfo);
	cursorInfo.bVisible = showFlag; // set the cursor visibility
	SetConsoleCursorInfo(out, &cursorInfo);
}

void WindowSize() {
	srand((unsigned)time(NULL));
	HWND console = GetConsoleWindow();
	RECT r;
	GetWindowRect(console, &r); //stores the console's current dimensions

	MoveWindow(console, r.left, r.top, 328, 390, TRUE); // 800 width, 100 height
}

int main() {

	WindowSize();
	Entities* myGameObject[2] = { nullptr, nullptr };
	GameMenu Menu;
	Menu.GameIntro();
	system("cls");

	int MagnitudeX, MagnitudeY;
	bool boss1defeated = false;
	int numberofbullets = 3, BDirection = 1;
	bool canshoot = true, changemap = false, SpawnMapOneEnemy = true;
	int Update = 0;
	bool hitenemy = false;
	string MapTransit = "E3"; // Spawn Map number
	bool Access = true;

    Bullets* BulletObject[5] = { nullptr, nullptr, nullptr, nullptr, nullptr };

	Map MapGrid;
	Map* map = &MapGrid;
	Player SpaceShip;
	Alien aliens;
	myGameObject[0] = &SpaceShip;
	myGameObject[1] = &aliens;
	myGameObject[1]->setXandY((rand() % 39) + 1, (rand() % 39) + 1);

	ShowConsoleCursor(false);

	//Play this during the boss fight, this is for testing
	//PlaySound(TEXT("Sonic 3 Music - Final Boss.wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);

	while (true) {
		cout << "  " << (char)3 << " x 3";
		if (MapTransit == "A1" and Access) {
			map->SetMapA1();
			Access = false;
		}

		if (MapTransit == "A2" and Access) {
			map->SetMapA2();
			Access = false;
		}

		if (MapTransit == "A3" and Access) {
			map->SetMapA3();
			Access = false;
		}

		if (MapTransit == "A4" and Access) {
			map->SetMapA4();
			Access = false;
		}

		if (MapTransit == "A5" and Access) {
			map->SetMapA5();
			Access = false;
		}

		if (MapTransit == "B1" and Access) {
			map->SetMapB1();
			Access = false;
		}

		if (MapTransit == "B2" and Access) {
			map->SetMapB2();
			Access = false;
		}

		if (MapTransit == "B3" and Access) {
			map->SetMapB3();
			Access = false;
		}

		if (MapTransit == "B4" and Access) {
			map->SetMapB4();
			Access = false;
		}

		if (MapTransit == "B5" and Access) {
			map->SetMapB5();
			Access = false;
		}

		if (MapTransit == "C1" and Access) {
			map->SetMapC1();
			Access = false;
		}

		if (MapTransit == "C2" and Access) {
			map->SetMapC2();
			Access = false;
		}

		if (MapTransit == "C3Normal" and Access) {
			map->SetMapC3Normal();
			Access = false;
		}

		if (MapTransit == "C4" and Access) {
			map->SetMapC4();
			Access = false;
		}

		if (MapTransit == "C5" and Access) {
			map->SetMapC5();
			Access = false;
		}

		if (MapTransit == "D1" and Access) {
			map->SetMapD1();
			Access = false;
		}

		if (MapTransit == "D2" and Access) {
			map->SetMapD2();
			Access = false;
		}

		if (MapTransit == "D3" and Access) {
			map->SetMapD3();
			Access = false;
		}

		if (MapTransit == "D4" and Access) {
			map->SetMapD4();
			Access = false;
		}

		if (MapTransit == "D5" and Access) {
			map->SetMapD5();
			Access = false;
		}

		if (MapTransit == "E1" and Access) {
			map->SetMapE1();
			Access = false;
		}

		if (MapTransit == "E2" and Access) {
			map->SetMapE2();
			Access = false;
		}

		if (MapTransit == "E3" and Access) {
			map->SetMapE3();
			Access = false;
		}
		if (MapTransit == "E4" and Access) {
			map->SetMapE4();
			Access = false;
		}

		if (MapTransit == "E5" and Access) {
			map->SetMapE5();
			Access = false;
		}
		clearScreen();
		map->SpawnMap();

		MagnitudeX = 0;
		MagnitudeY = 0;

		if (Update % 2 == 0) {
			if (GetAsyncKeyState(VK_UP)) {
				BDirection = 1;
				MagnitudeY = -1;
			}
			if (GetAsyncKeyState(VK_DOWN)) {
				BDirection = 2;
				MagnitudeY = 1;
			}
			if (GetAsyncKeyState(VK_RIGHT)) {
				BDirection = 4;
				MagnitudeX = 1;
			}
			if (GetAsyncKeyState(VK_LEFT)) {
				BDirection = 3;
				MagnitudeX = -1;
			}
			if (GetAsyncKeyState(VK_UP) and GetAsyncKeyState(VK_DOWN)) {
				MagnitudeY = 0;
			}
			if (GetAsyncKeyState(VK_LEFT) and GetAsyncKeyState(VK_RIGHT)) {
				MagnitudeX = 0;
			}
		}
		//delete all bullets + enemies
		if (changemap == true) {
			for (int i = 0; i < numberofbullets; i++) {
				if (BulletObject[i] != nullptr) {
					map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, -1, ' ');
					delete BulletObject[i];
					BulletObject[i] = nullptr;
				}
			}
			changemap = false;
		}

		if ((myGameObject[0]->GetX() < 3) || (myGameObject[0]->GetX() > 37) || (myGameObject[0]->GetY() < 3) || (myGameObject[0]->GetY() > 17)) {
			canshoot = false;
		}
		else {
			canshoot = true;
		}

		//spawn the arrow
		if (Update % 5 == 0) {
			if ((GetAsyncKeyState(VK_SPACE)) && (canshoot == true)) {
				for (int i = 0; i < numberofbullets; i++) {
					if (BulletObject[i] == nullptr) {
						if ((BDirection == 1) && (myGameObject[0]->GetY() != 0) && (map->CollisionY(myGameObject[0]->GetX(), myGameObject[0]->GetY(), -1, myGameObject[0]->GetName()) == 0)) {
							BulletObject[i] = new Bullets;
							BulletObject[i]->setBulletSymbol(1);
							BulletObject[i]->setOldPosition(myGameObject[0]->GetX(), myGameObject[0]->GetY() - 1);
							map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, -1, BulletObject[i]->getSymbol());
							BulletObject[i]->setOldPosition(myGameObject[0]->GetX(), myGameObject[0]->GetY() - 1);
							BulletObject[i]->setBulletDirection(1);
						}
						else if ((BDirection == 2) && (myGameObject[0]->GetY() != 40) && (map->CollisionY(myGameObject[0]->GetX(), myGameObject[0]->GetY(), 1, myGameObject[0]->GetName()) == 0)) {
							BulletObject[i] = new Bullets;
							BulletObject[i]->setBulletSymbol(1);
							BulletObject[i]->setOldPosition(myGameObject[0]->GetX(), myGameObject[0]->GetY() + 1);
							map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, 1, BulletObject[i]->getSymbol());
							BulletObject[i]->setOldPosition(myGameObject[0]->GetX(), myGameObject[0]->GetY() + 1);							BulletObject[i]->setBulletDirection(2);
						}
						else if ((BDirection == 3) && (myGameObject[0]->GetX() != 0) && (map->CollisionX(myGameObject[0]->GetX(), myGameObject[0]->GetY(), -1, myGameObject[0]->GetName()) == 0)) {
							BulletObject[i] = new Bullets;
							BulletObject[i]->setBulletSymbol(2);
							BulletObject[i]->setOldPosition(myGameObject[0]->GetX() - 1, myGameObject[0]->GetY());
							map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), -1, 0, BulletObject[i]->getSymbol());
							BulletObject[i]->setOldPosition(myGameObject[0]->GetX() - 1, myGameObject[0]->GetY());
							BulletObject[i]->setBulletDirection(3);
						}
						else if ((BDirection == 4) && (myGameObject[0]->GetX() != 20) && (map->CollisionX(myGameObject[0]->GetX(), myGameObject[0]->GetY(), 1, myGameObject[0]->GetName()) == 0)) {
							BulletObject[i] = new Bullets;
							BulletObject[i]->setBulletSymbol(2);
							BulletObject[i]->setOldPosition(myGameObject[0]->GetX() + 1, myGameObject[0]->GetY());
							map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 1, 0, BulletObject[i]->getSymbol());
							BulletObject[i]->setOldPosition(myGameObject[0]->GetX() + 1, myGameObject[0]->GetY());
							BulletObject[i]->setBulletDirection(4);
						}
						break;
					}
				}
			}
		}

		//update bullet
		for (int i = 0; i < numberofbullets; i++) {
			if (BulletObject[i] != nullptr) {
				if (BulletObject[i]->getBulletDIrection() == 1) {
					if (map->BulletCollisionY(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), -1, BulletObject[i]->getSymbol()) == 0) {
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, -1, BulletObject[i]->getSymbol());
						BulletObject[i]->setOldPosition(BulletObject[i]->getOldX(), BulletObject[i]->getOldy() - 1);
					}
					else {
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, -1, ' ');
						delete BulletObject[i];
						BulletObject[i] = nullptr;
					}
				}
				else if (BulletObject[i]->getBulletDIrection() == 2) {
					if ((map->BulletCollisionY(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 1, BulletObject[i]->getSymbol()) == 0) && (BulletObject[i]->getOldy() != 20)) {
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, 1, BulletObject[i]->getSymbol());
						BulletObject[i]->setOldPosition(BulletObject[i]->getOldX(), BulletObject[i]->getOldy() + 1);
					}
					else {
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, 1, ' ');
						delete BulletObject[i];
						BulletObject[i] = nullptr;
					}
				}
				else if (BulletObject[i]->getBulletDIrection() == 3) {
					if (map->BulletCollisionX(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), -1, BulletObject[i]->getSymbol()) == 0) {
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), -1, 0, BulletObject[i]->getSymbol());
						BulletObject[i]->setOldPosition(BulletObject[i]->getOldX() - 1, BulletObject[i]->getOldy());
					}
					else {
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), -1, 0, ' ');
						delete BulletObject[i];
						BulletObject[i] = nullptr;
					}
				}
				else {
					if ((map->BulletCollisionX(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 1, BulletObject[i]->getSymbol()) == 0) && (BulletObject[i]->getOldX() != 40)) {
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 1, 0, BulletObject[i]->getSymbol());
						BulletObject[i]->setOldPosition(BulletObject[i]->getOldX() + 1, BulletObject[i]->getOldy());
					}
					else {
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 1, 0, ' ');
						delete BulletObject[i];
						BulletObject[i] = nullptr;
					}
				}
			}
		}

		//Collision of the '#'
		if (map->CollisionX(myGameObject[0]->GetX(), myGameObject[0]->GetY(), MagnitudeX, myGameObject[0]->GetName())) {
			MagnitudeX = 0;
			canshoot = false;
		}
		else
			canshoot = true;
		if (map->CollisionY(myGameObject[0]->GetX(), myGameObject[0]->GetY(), MagnitudeY, myGameObject[0]->GetName())) {
			MagnitudeY = 0;
			canshoot = false;
		}
		else
			canshoot = true;

		// Movement and spawnning of entities
		myGameObject[0]->moveX(myGameObject[0]->GetX(), MagnitudeX);
		myGameObject[0]->moveY(myGameObject[0]->GetY(), MagnitudeY);
		map->DrawEntities(myGameObject[0]->GetX(), myGameObject[0]->GetY(), MagnitudeX, MagnitudeY, myGameObject[0]->GetName());

		//Map Number A2 to A3
		for (int i = 2; i <= 11; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "A2" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "A3";
				changemap = true;
			}
		}

		//Map Number A3 to A2
		for (int i = 2; i <= 11; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "A3" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "A2";
				changemap = true;
			}
		}

		//Map Number A3 to A4
		for (int i = 2; i <= 11; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "A3" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "A4";
				changemap = true;
			}
		}

		//Map Number A4 to A3
		for (int i = 2; i <= 11; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "A4" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "A3";
				changemap = true;
			}
		}

		//Map Number A4 to A5
		for (int i = 2; i <= 16; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "A4" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "A5";
				changemap = true;
			}
		}

		//Map Number A5 to A4
		for (int i = 2; i <= 16; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "A5" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "A4";
				changemap = true;
			}
		}

		//Map Number A1 to A2
		for (int i = 2; i <= 11; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "A1" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "A2";
				changemap = true;
			}
		}

		//Map Number A2 to A1
		for (int i = 2; i <= 11; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "A2" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "A1";
				changemap = true;
			}
		}

		//Map Number B1 to A1
		for (int i = 2; i <= 23; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "B1" and GetAsyncKeyState(VK_UP)) {
				myGameObject[0]->setXandY(i, 19);
				Access = true;
				MapTransit = "A1";
				changemap = true;
			}
		}

		//Map Number A1 to B1
		for (int i = 2; i <= 23; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "A1" and GetAsyncKeyState(VK_DOWN)) {
				myGameObject[0]->setXandY(i, 1);
				Access = true;
				MapTransit = "B1";
				changemap = true;
			}
		}


		//Map Number B2 to A2
		for (int i = 17; i <= 35; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "B2" and GetAsyncKeyState(VK_UP)) {
				myGameObject[0]->setXandY(i, 19);
				Access = true;
				MapTransit = "A2";
				changemap = true;
			}
		}

		//Map Number A2 to B2
		for (int i = 17; i <= 35; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "A2" and GetAsyncKeyState(VK_DOWN)) {
				myGameObject[0]->setXandY(i, 1);
				Access = true;
				MapTransit = "B2";
				changemap = true;
			}
		}


		//Map Number B3 to A3
		for (int i = 15; i <= 25; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "B3" and GetAsyncKeyState(VK_UP)) {
				myGameObject[0]->setXandY(i, 19);
				Access = true;
				MapTransit = "A3";
				changemap = true;
			}
		}

		//Map Number A3 to B3
		for (int i = 15; i <= 25; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "A3" and GetAsyncKeyState(VK_DOWN)) {
				myGameObject[0]->setXandY(i, 1);
				Access = true;
				MapTransit = "B3";
				changemap = true;
			}
		}

		//Map Number B4 to A4
		for (int i = 15; i <= 25; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "B4" and GetAsyncKeyState(VK_UP)) {
				myGameObject[0]->setXandY(i, 19);
				Access = true;
				MapTransit = "A4";
				changemap = true;
			}
		}

		//Map Number A4 to B4
		for (int i = 15; i <= 25; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "A4" and GetAsyncKeyState(VK_DOWN)) {
				myGameObject[0]->setXandY(i, 1);
				Access = true;
				MapTransit = "B4";
				changemap = true;
			}
		}

		//Map Number B5 to A5
		for (int i = 15; i <= 38; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "B5" and GetAsyncKeyState(VK_UP)) {
				myGameObject[0]->setXandY(i, 19);
				Access = true;
				MapTransit = "A5";
				changemap = true;
			}
		}

		//Map Number A5 to B5
		for (int i = 15; i <= 38; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "A5" and GetAsyncKeyState(VK_DOWN)) {
				myGameObject[0]->setXandY(i, 1);
				Access = true;
				MapTransit = "B5";
				changemap = true;
			}
		}
		//Map Number B1 to B2
		for (int i = 9; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "B1" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "B2";
				changemap = true;
			}
		}

		//Map Number B2 to B1
		for (int i = 9; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "B2" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				changemap = true;
				MapTransit = "B1";
			}
		}

		//Map Number B2 to B3
		for (int i = 2; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "B2" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "B3";
				changemap = true;
			}
		}

		//Map Number B3 to B2
		for (int i = 2; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "B3" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "B2";
				changemap = true;
			}
		}

		//Map Number B3 to B4
		for (int i = 2; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "B3" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "B4";
				changemap = true;
			}
		}

		//Map Number B4 to B3
		for (int i = 2; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "B4" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "B3";
				changemap = true;
			}
		}


		//Map Number B4 to B5
		for (int i = 2; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "B4" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "B5";
				changemap = true;
			}
		}

		//Map Number B5 to B4
		for (int i = 2; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "B5" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "B4";
				changemap = true;
			}
		}


		//Map Number C1 to B1
		for (int i = 2; i <= 8; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "C1" and GetAsyncKeyState(VK_UP)) {
				myGameObject[0]->setXandY(i, 19);
				Access = true;
				MapTransit = "B1";
				changemap = true;
			}
		}

		//Map Number B1 to C1
		for (int i = 2; i <= 8; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "B1" and GetAsyncKeyState(VK_DOWN)) {
				myGameObject[0]->setXandY(i, 1);
				Access = true;
				MapTransit = "C1";
				changemap = true;
			}
		}



		//Map Number C3Normal to B3
		for (int i = 15; i <= 25; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "C3Normal" and GetAsyncKeyState(VK_UP)) {
				myGameObject[0]->setXandY(i, 19);
				Access = true;
				MapTransit = "B3";
				changemap = true;
			}
		}

		//Map Number B3 to C3Normal
		for (int i = 15; i <= 25; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "B3" and GetAsyncKeyState(VK_DOWN)) {
				myGameObject[0]->setXandY(i, 1);
				Access = true;
				MapTransit = "C3Normal";
				changemap = true;
			}
		}


		//Map Number C2 to C1
		for (int i = 8; i <= 12; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "C2" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "C1";
				changemap = true;
			}
		}


		//Map Number C1 to C2
		for (int i = 8; i <= 12; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "C1" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "C2";
				changemap = true;
			}
		}



		//Map Number C5 to C4
		for (int i = 8; i <= 12; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "C5" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "C4";
				changemap = true;
			}
		}


		//Map Number C4 to C5
		for (int i = 8; i <= 12; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "C4" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "C5";
				changemap = true;
			}
		}



		//Map Number C3Normal to C2
		for (int i = 8; i <= 12; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "C3Normal" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "C2";
				changemap = true;
			}
		}


		//Map Number C2 to C3Normal
		for (int i = 8; i <= 12; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "C2" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "C3Normal";
				changemap = true;
			}
		}

		//Map Number C3Normal to C4
		for (int i = 8; i <= 12; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "C3Normal" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "C4";
				changemap = true;
			}
		}


		//Map Number C4 to C3Normal
		for (int i = 8; i <= 12; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "C4" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "C3Normal";
				changemap = true;
			}
		}



		//Map Number D5 to C5
		for (int i = 32; i <= 38; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "D5" and GetAsyncKeyState(VK_UP)) {
				myGameObject[0]->setXandY(i, 19);
				Access = true;
				MapTransit = "C5";
				changemap = true;
			}
		}

		//Map Number C5 to D5
		for (int i = 32; i <= 38; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "C5" and GetAsyncKeyState(VK_DOWN)) {
				myGameObject[0]->setXandY(i, 1);
				Access = true;
				MapTransit = "D5";
				changemap = true;
			}
		}


		//Map Number C5 to B5
		for (int i = 32; i <= 38; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "C5" and GetAsyncKeyState(VK_UP)) {
				myGameObject[0]->setXandY(i, 19);
				Access = true;
				MapTransit = "B5";
				changemap = true;
			}
		}

		//Map Number B5 to C5
		for (int i = 32; i <= 38; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "B5" and GetAsyncKeyState(VK_DOWN)) {
				myGameObject[0]->setXandY(i, 1);
				Access = true;
				MapTransit = "C5";
				changemap = true;
			}
		}

		//Map Number E4 to D4
		for (int i = 5; i <= 25; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "E4" and GetAsyncKeyState(VK_UP)) {
				myGameObject[0]->setXandY(i, 19);
				Access = true;
				changemap = true;
				MapTransit = "D4";
			}
		}

		//Map Number D4 to E4
		for (int i = 5; i <= 25; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "D4" and GetAsyncKeyState(VK_DOWN)) {
				myGameObject[0]->setXandY(i, 1);
				Access = true;
				MapTransit = "E4";
				changemap = true;
			}
		}


		//Map Number D1 to D2
		for (int i = 2; i <= 12; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "D1" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				changemap = true;
				MapTransit = "D2";
			}
		}

		//Map Number D2 to D1
		for (int i = 2; i <= 12; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "D2" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "D1";
				changemap = true;
			}
		}


		//Map Number D1 to C1
		for (int i = 2; i <= 8; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "D1" and GetAsyncKeyState(VK_UP)) {
				myGameObject[0]->setXandY(i, 19);
				Access = true;
				MapTransit = "C1";
				changemap = true;
			}
		}

		//Map Number C1 to D1
		for (int i = 2; i <= 8; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "C1" and GetAsyncKeyState(VK_DOWN)) {
				myGameObject[0]->setXandY(i, 1);
				Access = true;
				MapTransit = "D1";
				changemap = true;
			}
		}


		//Map Number E3 to D3
		for (int i = 15; i <= 25; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "E3" and GetAsyncKeyState(VK_UP)) {
				myGameObject[0]->setXandY(i, 19);
				Access = true;
				MapTransit = "D3";
				changemap = true;
			}
		}

		//Map Number D3 to E3
		for (int i = 15; i <= 25; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "D3" and GetAsyncKeyState(VK_DOWN)) {
				myGameObject[0]->setXandY(i, 1);
				Access = true;
				MapTransit = "E3";
				changemap = true;
			}
		}

		//Map Number D2 to D3
		for (int i = 2; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "D2" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "D3";
				changemap = true;
			}
		}

		//Map Number D3 to D4
		for (int i = 2; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "D3" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1,i);
				Access = true;
				MapTransit = "D4";
				changemap = true;
			}
		}

		//Map Number D3 to C3Normal
		for (int i = 15; i <= 25; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "D3" and GetAsyncKeyState(VK_UP)) {
				myGameObject[0]->setXandY(i, 19);
				Access = true;
				MapTransit = "C3Normal";
				changemap = true;
			}
		}

		//Map Number C3Normal to D3
		for (int i = 15; i <= 25; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "C3Normal" and GetAsyncKeyState(VK_DOWN)) {
				myGameObject[0]->setXandY(i, 1);
				Access = true;
				MapTransit = "D3";
				changemap = true;
			}
		}

		//Map Number D3 to D2
		for (int i = 2; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "D3" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "D2";
				changemap = true;
			}
		}

		//Map Number D4 to D3
		for (int i = 2; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "D4" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39,i);
				Access = true;
				MapTransit = "D3";
				changemap = true;
			}
		}


		//Map Number D4 to D5
		for (int i = 2; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "D4" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "D5";
				changemap = true;
			}
		}

		//Map Number D5 to D4
		for (int i = 2; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "D5" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "D4";
				changemap = true;
			}
		}





		//Map Number E1 to D1
		for (int i = 2; i <= 24; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "E1" and GetAsyncKeyState(VK_UP)) {
				myGameObject[0]->setXandY(i, 19);
				Access = true;
				MapTransit = "D1";
				changemap = true;
			}
		}

		//Map Number D1 to E1
		for (int i = 2; i <= 24; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "D1" and GetAsyncKeyState(VK_DOWN)) {
				myGameObject[0]->setXandY(i, 1);
				Access = true;
				MapTransit = "E1";
				changemap = true;
			}
		}






		//Map Number E2 to D2
		for (int i = 15; i <= 25; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "E2" and GetAsyncKeyState(VK_UP)) {
				myGameObject[0]->setXandY(i, 19);
				Access = true;
				MapTransit = "D2";
				changemap = true;
			}
		}

		//Map Number D2 to E2
		for (int i = 15; i <= 25; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "D2" and GetAsyncKeyState(VK_DOWN)) {
				myGameObject[0]->setXandY(i, 1);
				Access = true;
				MapTransit = "E2";
				changemap = true;
			}
		}

		// Map Number E1 to E2
		for (int i = 8; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "E1" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "E2";
				changemap = true;
			}
		}

		// Map Number E2 to E1
		for (int i = 8; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "E2" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "E1";
				changemap = true;
			}
		}

		// Map Number E3 to E2
		for (int i = 8; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "E3" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "E2";
				changemap = true;
			}
		}

		// Map Number E2 to E3
		for (int i = 8; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "E2" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "E3";
				changemap = true;
			}
		}

		// Map Number E3 to E4
		for (int i = 8; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "E3" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "E4";
				changemap = true;
			}
		}

		// Map Number E4 to E3
		for (int i = 8; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "E4" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = "E3";
				changemap = true;
			}
		}

		// Map Number E4 to E5
		for (int i = 8; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "E4" and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = "E5";
				changemap = true;
			}
		}

		// Map Number E5 to E4
		for (int i = 8; i <= 18; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "E5" and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				changemap = true;
				MapTransit = "E4";
			}
		}

		//Map Number E5 to D5
		for (int i = 15; i <= 39; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "E5" and GetAsyncKeyState(VK_UP)) {
				myGameObject[0]->setXandY(i, 19);
				Access = true;
				MapTransit = "D5";
				changemap = true;
			}
		}

		//Map Number D5 to E5
		for (int i = 15; i <= 39; i++) {
			if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "D5" and GetAsyncKeyState(VK_DOWN)) {
				myGameObject[0]->setXandY(i, 1);
				Access = true;
				MapTransit = "E5";
				changemap = true;
			}
		}

		Update++;
	}
	return 0;
}