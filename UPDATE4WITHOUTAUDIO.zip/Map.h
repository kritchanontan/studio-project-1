#pragma once

class Map
{
private:
	char MapSize[21][41];
public:
	void SetMap1();
	void SetMap2();
	void SetMap3();
	void SpawnMap();
	bool CollisionX(int PosX, int PosY, int MagnitudeX, char name);
	bool CollisionY(int PosX, int PosY, int MagnitudeY, char name);
	void DrawEntities(int x, int y, int MagnitudeX, int MagnitudeY, char name);
};

