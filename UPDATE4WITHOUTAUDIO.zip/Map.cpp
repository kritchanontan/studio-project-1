#include "Map.h"
#include <iostream>
using namespace std;

void Map::SetMap1()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			if (i > 0 and i < 20) {
				MapSize[i][j] = ' ';
			}
			if (i == 20 and j > 0 and j < 40) {
				MapSize[i][j] = (char)205;
			}
			if (j == 0 and i > 0 and i < 20) {
				MapSize[i][j] = (char)186;
			}
			if (j == 40 and i > 0 and i < 20) {
				MapSize[i][j] = (char)186;
			}
			MapSize[0][0] = (char)201;
			MapSize[0][40] = (char)187;
			MapSize[20][0] = (char)200;
			MapSize[20][40] = (char)188;


			if (i == 0 and j > 0 and j < 40) {
				MapSize[i][j] = (char)205;
			}
			if (i >= 18 and i < 20 and j > 0 and j < 40) {
				MapSize[i][j] = '#';
			}
			if (i >= 1 and i < 9 and j > 0 and j < 40) {
				MapSize[i][j] = '#';
			}
			for (int i = 1; i < 9; i++) {
				for (int j = 15; j < 25; j++) {
					MapSize[i][j] = ' ';
				}
			}

			if (i >= 9 and i < 15 and j > 0 and j < 40) {
				MapSize[i][j] = '#';
			}

			for (int i = 9; i <= 15; i++) {
				for (int j = 5; j <= 35; j++) {
					MapSize[i][j] = ' ';
				}
			}

			MapSize[15][0] = ' ';
			MapSize[16][0] = ' ';
			MapSize[17][0] = ' ';
			MapSize[15][40] = ' ';
			MapSize[16][40] = ' ';
			MapSize[17][40] = ' ';
			for (int i = 15; i < 25; i++) {
				MapSize[0][i] = ' ';
			}
		}
		cout << endl;
	}

}

void Map::SetMap2()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			if (i == 0 and j > 0 and j < 40) {
				MapSize[i][j] = (char)205;
			}
			if (i == 20 and j > 0 and j < 40) {
				MapSize[i][j] = (char)205;
			}
			if (i > 0 and i < 20) {
				MapSize[i][j] = ' ';
			}
			if (j == 0 and i > 0 and i < 20) {
				MapSize[i][j] = (char)186;
			}
			if (j == 40 and i > 0 and i < 20) {
				MapSize[i][j] = (char)186;
			}
			MapSize[0][0] = (char)201;
			MapSize[0][40] = (char)187;
			MapSize[20][0] = (char)200;
			MapSize[20][40] = (char)188;

			MapSize[15][40] = ' ';
			MapSize[16][40] = ' ';
			MapSize[17][40] = ' ';
		}
		cout << endl;
	}

}


//Map1
void Map::SpawnMap()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			cout << MapSize[i][j];
		}
		cout << endl;
	}
}

bool Map::CollisionX(int PosX, int PosY, int MagnitudeX, char name)
{
	if (MagnitudeX == -1) {
		if (MapSize[PosY][PosX - 1] == '#') {
			return true;
		}
	}
	if (MagnitudeX == 1) {
		if (MapSize[PosY][PosX + 1] == '#') {
			return true;
		}
	}
	return false;
}

bool Map::CollisionY(int PosX, int PosY, int MagnitudeY, char name)
{
	if (MagnitudeY == -1) {
		if (MapSize[PosY - 1][PosX] == '#') {
			return true;
		}
	}
	if (MagnitudeY == 1) {
		if (MapSize[PosY + 1][PosX] == '#') {
			return true;
		}
	}
	return false;
}

void Map::DrawEntities(int PosX, int PosY, int MagnitudeX, int MagnitudeY, char name)
{ 
	// Spawn Entities
	MapSize[PosY][PosX] = name;

	// Left Arrow Movement
	if (MagnitudeX == -1) {
		MapSize[PosY][PosX + 1] = ' ';
	}

	// Right Arrow Movement
	if (MagnitudeX == 1) {
		MapSize[PosY][PosX - 1] = ' ';
	}

	// Up Arrow Movement
	if (MagnitudeY == -1) {
		MapSize[PosY + 1][PosX] = ' ';
	}

	// Down Arrow Movement
	if (MagnitudeY == 1) {
		MapSize[PosY - 1][PosX] = ' ';
	}

	// Up and right arrow
	if (MagnitudeX == 1 and MagnitudeY == -1) {
		MapSize[PosY + 1][PosX - 1] = ' ';
	}

	// Down and left arrow
	if (MagnitudeX == -1 and MagnitudeY == 1) {
		MapSize[PosY - 1][PosX + 1] = ' ';
	}

	// down and right arrow
	if (MagnitudeX == 1 and MagnitudeY == 1) {
		MapSize[PosY - 1][PosX - 1] = ' ';
	}

	// Up and left arrow
	if (MagnitudeX == -1 and MagnitudeY == -1) {
		MapSize[PosY + 1][PosX + 1] = ' ';
	}
}
