#include "Entities.h"
#include <string>

Entities::Entities()
{
	x = 20;
	y = 10;
	character = '?';
}

void Entities::moveX(int MoveX, int MagnitudeX)
{
	x = MoveX;
	x += MagnitudeX;

	if (x <= 0) {
		x = 1;
	}

	if (x >= 40) {
		x = 39;
	}
}

void Entities::moveY(int MoveY, int MagnitudeY)
{
	y = MoveY;
	y += MagnitudeY;

	if (y <= 0) {
		y = 1;
	}
	if (y >= 20) {
		y = 19;
	}
}

char Entities::GetName() const
{
	return character;
}

void Entities::setXandY(int NewX, int NewY)
{
	if (NewX > 0 and NewX < 40 and NewY > 0 and NewY < 20) {
		x = NewX;
		y = NewY;
	}
}

int Entities::GetX() const
{
	return x;
}

int Entities::GetY() const
{
	return y;
}

Entities::~Entities()
{
}
