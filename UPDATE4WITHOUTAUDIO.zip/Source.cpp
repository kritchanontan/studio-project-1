#include <iostream>
#include "Map.h"
#include <windows.h>
#include "Entities.h"
#include "Player.h"
#include "Alien.h"
#include "GameMenu.h"
#include "Bullets.h"
#pragma comment(lib,"Winmm.lib")
using namespace std;

void clearScreen()
{
	HANDLE hOut;
	COORD Position;

	hOut = GetStdHandle(STD_OUTPUT_HANDLE);

	Position.X = 0;
	Position.Y = 0;
	SetConsoleCursorPosition(hOut, Position);
}

void ShowConsoleCursor(bool showFlag)
{
	HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);

	CONSOLE_CURSOR_INFO     cursorInfo;

	GetConsoleCursorInfo(out, &cursorInfo);
	cursorInfo.bVisible = showFlag; // set the cursor visibility
	SetConsoleCursorInfo(out, &cursorInfo);
}

void WindowSize() {
	srand((unsigned)time(NULL));
	HWND console = GetConsoleWindow();
	RECT r;
	GetWindowRect(console, &r); //stores the console's current dimensions

	MoveWindow(console, r.left, r.top, 328, 390, TRUE); // 800 width, 100 height
}

int main() {
	WindowSize();
	Entities* myGameObject[2] = { nullptr, nullptr };
	GameMenu Menu;
	Menu.GameIntro();
	system("cls");
	int MagnitudeX, MagnitudeY;

	int MapTransit = 0;
	bool Access = true;

	Bullets* BulletObject[3] = { nullptr, nullptr, nullptr };

	Map MapGrid;
	Map* map = &MapGrid;
	Player SpaceShip;
	Alien aliens;
	myGameObject[0] = &SpaceShip;
	myGameObject[1] = &aliens;
	myGameObject[1]->setXandY((rand() % 39) + 1, (rand() % 39) + 1);

	char direction;
	ShowConsoleCursor(false);

	//Play this during the boss fight, this is for testing
	PlaySound(TEXT("SONIC GENERATIONS BIG ARMS.wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);

	while (true) {
		if (MapTransit == 0 and Access) {
			map->SetMap1();
			Access = false;
		}

		if (MapTransit == 1 and Access) {
			map->SetMap2();
			Access = false;
		}

		clearScreen();
		map->SpawnMap();

		MagnitudeX = 0;
		MagnitudeY = 0;
		if (GetAsyncKeyState(VK_UP)) {
			direction = 'w';
			MagnitudeY = -1;
		}
		if (GetAsyncKeyState(VK_DOWN)) {
			direction = 's';
			MagnitudeY = 1;
		}
		if (GetAsyncKeyState(VK_RIGHT)) {
			direction = 'd';
			MagnitudeX = 1;
		}
		if (GetAsyncKeyState(VK_LEFT)) {
			direction = 'a';
			MagnitudeX = -1;
		}

		//spawn the bullet
		//if (GetAsyncKeyState(VK_SPACE)) {
		//	for (int i = 0; i < 3; i++) {
		//		if (BulletObject[i] == nullptr) {
		//			BulletObject[i] = new Bullets;
		//			if (direction == 'w') {
		//				BulletObject[i]->setBulletSymbol(1);
		//				BulletObject[i]->setOldPosition(myGameObject[0]->GetX(), myGameObject[0]->GetY() - 1);
		//				map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, -1, BulletObject[i]->getSymbol());
		//			}
		//			else if (direction == 's') {
		//				BulletObject[i]->setBulletSymbol(1);
		//				BulletObject[i]->setOldPosition(myGameObject[0]->GetX(), myGameObject[0]->GetY() + 1);
		//				map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, 1, BulletObject[i]->getSymbol());
		//			}
		//			else if (direction == 'a') {
		//				BulletObject[i]->setBulletSymbol(2);
		//				BulletObject[i]->setOldPosition(myGameObject[0]->GetX() - 1, myGameObject[0]->GetY());
		//				map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), -1, 0, BulletObject[i]->getSymbol());
		//			}
		//			else {
		//				BulletObject[i]->setBulletSymbol(2);
		//				BulletObject[i]->setOldPosition(myGameObject[0]->GetX() + 1, myGameObject[0]->GetY());
		//				map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 1, 0, BulletObject[i]->getSymbol());
		//			}
		//		}
		//	}
		//}

		//update the bullet
		//for (int i = 0; i < 3; i++) {
		//	if (BulletObject[i] != nullptr) {
		//		if direction
		//			BulletObject[i]->setNewPosition
		//	}
		//}

		Sleep(20);

		if (map->CollisionX(myGameObject[0]->GetX(), myGameObject[0]->GetY(), MagnitudeX, myGameObject[0]->GetName())) {
			MagnitudeX = 0;
		}
		if (map->CollisionY(myGameObject[0]->GetX(), myGameObject[0]->GetY(), MagnitudeY, myGameObject[0]->GetName())) {
			MagnitudeY = 0;
		}

		myGameObject[0]->moveX(myGameObject[0]->GetX(), MagnitudeX);
		myGameObject[0]->moveY(myGameObject[0]->GetY(), MagnitudeY);
		map->DrawEntities(myGameObject[0]->GetX(), myGameObject[0]->GetY(), MagnitudeX, MagnitudeY, myGameObject[0]->GetName());


		for (int i = 15; i <= 17; i++) {
			if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == 0 and GetAsyncKeyState(VK_LEFT)) {
				myGameObject[0]->setXandY(39, i);
				Access = true;
				MapTransit = 1;
			}
		}
		for (int i = 15; i <= 17; i++) {
			if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == 1 and GetAsyncKeyState(VK_RIGHT)) {
				myGameObject[0]->setXandY(1, i);
				Access = true;
				MapTransit = 0;
			}
		}


	}
	return 0;
}