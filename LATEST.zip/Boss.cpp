#include "Boss.h"

Boss::Boss()
{
	x = 0;
	y = 0;
	character = 'B';
}

Boss::~Boss()
{
}

void Boss::moveX(int MoveX, int MagnitudeX)
{
	x = MoveX;
	x += MagnitudeX;

	if (x <= 0) {
		x = 1;
	}

	if (x >= 40) {
		x = 39;
	}
}

void Boss::moveY(int MoveY, int MagnitudeY)
{
	y = MoveY;
	y += MagnitudeY;

	if (y <= 0) {
		y = 1;
	}
	if (y >= 20) {
		y = 19;
	}
}


void Boss::setXandY(int NewX, int NewY)
{
	if (NewX > 0 and NewX < 40 and NewY > 0 and NewY < 20) {
		x = NewX;
		y = NewY;
	}
}

void Boss::playertracking(int px, int py) {
	if (y < py and x < px) {
		y++;
		x++;
	}
	else if (y > py and x > px) {
		y--;
		x--;
	}
	else if (y > py and x < px) {
		y--;
		x++;
	}
	else if (y < py and x > px) {
		y++;
		x--;
	}
	else if (y == py and x < px) {
		x++;
	}
	else if (y < py and x == px) {
		y++;
	}

	else if (y == py and x > px) {
		x--;
	}
	else if (y > py and x == px) {
		y--;
	}
}