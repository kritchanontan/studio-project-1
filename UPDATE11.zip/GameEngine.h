#pragma once
#include <windows.h>

class GameEngine
{
public:
	void GameClearScreen();
	void GameIntro();
	void GameHelp();
	void GameHelp2();
	void GameCredits();
	void GameDialogueIntro();
	void GamePause();
	void GameTextFont();
	void PlayerKilledByEnemyDialogue();
	void PlayerKilledByMiniBossDialogue();
	void PlayerKilledByFinalBossDialogue();
	void GameScreenCursor(bool showFlag);
	void lockWindow();
	void WindowSize();
};

