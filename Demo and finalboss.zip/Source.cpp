﻿#include <iostream>
#include "Map.h"
#include <windows.h>
#include "Entities.h"
#include "Player.h"
#include "Enemy.h"
#include "GameEngine.h"
#include "Boss.h"
#include "Bullets.h"
#include "FinalBoss.h"
#pragma comment(lib,"Winmm.lib")
using namespace std;

int main() {
	GameEngine GameEngineSetup;
	GameEngineSetup.WindowSize();
	GameEngineSetup.lockWindow();
	GameEngineSetup.GameTextFont();
	GameEngineSetup.GameScreenCursor(false);
	srand((unsigned)time(NULL));
	Entities* myGameObject[10] = { nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr };

	bool Artifact1 = false, Artifact2 = false, Artifact3 = false, Artifact4 = false;
	int MagnitudeX, MagnitudeY;
	bool boss1defeated = false;
	int numberofbullets = 3, BDirection = 1, BBDirection = 1, FinalBossUpdate = 0,firerate = 10;
	bool canshoot = true, changemap = false, SpawnMapBoss3 = true, SpawnMapBoss1 = true,Spawnfinalboss = true, FinalBossDefeated = false;
	int Update = 0, clip = 3;
	string MapTransit = "E3"; // Spawn Map number
	bool Access = true;
	bool hitentity = false;
	bool Triggers3 = true, Triggers1 = true;
	Bullets* BulletObject[5] = { nullptr, nullptr, nullptr, nullptr, nullptr };
	Bullets* BossBulletObject[7] = { nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr };

	Map MapGrid;
	Map* map = &MapGrid;

	//Play this during the boss fight, this is for testing
	/*PlaySound(TEXT("Legend of Zelda, The (NES) Music - Overworld Theme.wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);*/

	// Declare to prevent enemy from moving diagonally
	int bossX, bossY;
	int e1randX1, e1randY1;
	int e1randX2, e1randY2;
	int e1randX3, e1randY3;
	int e1randX4, e1randY4;
	int x1, x2, x3, x4, y1, y2, y3, y4;
	bool running1 = true;
	bool running2 = false;
	bool allowBosstoMove3 = false;
	while (true) {
		bossX = 0;
		bossY = 0;
		if (myGameObject[0] != nullptr) {
			GameEngineSetup.ShowPlrHealth(myGameObject[0]->gethealth());
		}
		GameEngineSetup.BossKeys(Artifact1, Artifact2, Artifact3, Artifact4);
		//-----------------------------------------------------------------------------------------------------------------------------
		if (running1) {
			HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
			SetConsoleTextAttribute(hConsole, 7);
			system("cls");
			GameEngineSetup.GameIntro();
			system("cls");
			GameEngineSetup.GameDialogueIntro();
			SpawnMapBoss3 = true;
			if (myGameObject[0] == nullptr) {
				myGameObject[0] = new Player;
				myGameObject[0]->setXandY(10, 16);
			}

			for (int i = 1; i < 5; i++) {
				if (myGameObject[i] == nullptr) {
					myGameObject[i] = new Enemy;
					myGameObject[i]->sethealth(3);
					while (true) {
						myGameObject[i]->setXandY(rand() % 35 + 6, rand() % 15 + 5);
						if (map->CheckMap(myGameObject[i]->GetY(), myGameObject[i]->GetX()) == false) {
							break;
						}
						else {
							continue;
						}
					}
				}

			}
			running1 = false;
		}
		//-----------------------------------------------------------------------------------------------------------------------------
		x1 = 0;
		x2 = 0;
		x3 = 0;
		x4 = 0;
		y1 = 0;
		y2 = 0;
		y3 = 0;
		y4 = 0;
		MagnitudeX = 0;
		MagnitudeY = 0;

		//--------------------------------------------------------------------------------------------------------

		if (myGameObject[0] != nullptr) {
			if (myGameObject[0]->gethealth() == 0) {
				running2 = true;
				Access = true;
				Triggers3 = true;
				allowBosstoMove3 = false;
				MapTransit = "E3";
			}
		}

		if (running2) {
			for (int i = 0; i < 6; i++) {
				if (myGameObject[i] != nullptr) {
					map->DrawEntities(myGameObject[i]->GetX(), myGameObject[i]->GetY(), 0, -1, ' ');
					delete myGameObject[i];
					myGameObject[i] = nullptr;
				}
			}

			system("cls");
			HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
			SetConsoleTextAttribute(hConsole, 7);
			cout << "You died" << endl;
			system("pause");
			running1 = true;
			running2 = false;
		}
		//-----------------------------------------------------------------------------------------------------------
		// Set Map from A1 to E5
		if (MapTransit == "A1" and Access) {
			map->SetMapA1();
			Access = false;
		}

		if (MapTransit == "A2" and Access) {
			map->SetMapA2();
			Access = false;
		}

		if (MapTransit == "A3" and Access) {
			map->SetMapA3();
			Access = false;
		}

		if (MapTransit == "A4" and Access) {
			map->SetMapA4();
			Access = false;
		}

		if (MapTransit == "A5" and Access) {
			map->SetMapA5();
			Access = false;
		}

		if (MapTransit == "B1" and Access) {
			map->SetMapB1();
			Access = false;
		}

		if (MapTransit == "B2" and Access) {
			map->SetMapB2();
			Access = false;
		}

		if (MapTransit == "B3" and Access) {
			map->SetMapB3();
			Access = false;
		}

		if (MapTransit == "B4" and Access) {
			map->SetMapB4();
			Access = false;
		}

		if (MapTransit == "B5" and Access) {
			map->SetMapB5();
			Access = false;
		}

		if (MapTransit == "C1" and Access) {
			map->SetMapC1();
			Access = false;
		}

		if (MapTransit == "C2" and Access) {
			map->SetMapC2();
			Access = false;
		}

		if (MapTransit == "C3Normal" and Access) {
			map->SetMapC3Normal();
			Access = false;
		}

		if (MapTransit == "C4" and Access) {
			map->SetMapC4();
			Access = false;
		}

		if (MapTransit == "C5" and Access) {
			map->SetMapC5();
			Access = false;
		}

		if (MapTransit == "D1" and Access) {
			map->SetMapD1();
			Access = false;
		}

		if (MapTransit == "D2" and Access) {
			map->SetMapD2();
			Access = false;
		}

		if (MapTransit == "D3" and Access) {
			map->SetMapD3();
			Access = false;
		}

		if (MapTransit == "D4" and Access) {
			map->SetMapD4();
			Access = false;
		}

		if (MapTransit == "D5" and Access) {
			map->SetMapD5();
			Access = false;
		}

		if (MapTransit == "E1" and Access) {
			map->SetMapE1(false);
			Access = false;
		}

		if (MapTransit == "E2" and Access) {
			map->SetMapE2();
			Access = false;
		}

		if (MapTransit == "E3" and Access) {
			map->SetMapE3();
			Access = false;
		}
		if (MapTransit == "E4" and Access) {
			map->SetMapE4();
			Access = false;
		}

		if (MapTransit == "E5" and Access) {
			map->SetMapE5();
			Access = false;
		}

		// Move Vertical and Horizontal
		while (true) {
			x1 = (rand() % 3) - 1;
			y1 = (rand() % 3) - 1;
			x2 = (rand() % 3) - 1;
			y2 = (rand() % 3) - 1;
			x3 = (rand() % 3) - 1;
			y3 = (rand() % 3) - 1;
			x4 = (rand() % 3) - 1;
			y4 = (rand() % 3) - 1;
			if ((x1 == 1) and (y1 == 1) || (x1 == -1) and (y1 == 1) || (x1 == 1) and (y1 == -1) || (x1 == -1) and (y1 == -1)) {
				continue;
			}
			else if ((x2 == 1) and (y2 == 1) || (x2 == -1) and (y2 == 1) || (x2 == 1) and (y2 == -1) || (x2 == -1) and (y2 == -1)) {
				continue;
			}
			else if ((x3 == 1) and (y3 == 1) || (x3 == -1) and (y3 == 1) || (x3 == 1) and (y3 == -1) || (x3 == -1) and (y3 == -1)) {
				continue;
			}
			else if ((x4 == 1) and (y4 == 1) || (x4 == -1) and (y4 == 1) || (x4 == 1) and (y4 == -1) || (x4 == -1) and (y4 == -1)) {
				continue;
			}
			else {
				break;
			}
		}

		GameEngineSetup.GameClearScreen();
		map->SpawnMap();

		if (Update % 2 == 0) {
			if (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W')) {
				BDirection = 1;
				MagnitudeY = -1;
			}
			if (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S')) {
				BDirection = 2;
				MagnitudeY = 1;
			}
			if (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D')) {
				BDirection = 4;
				MagnitudeX = 1;
			}
			if (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A')) {
				BDirection = 3;
				MagnitudeX = -1;
			}
			if ((GetAsyncKeyState(VK_UP) and GetAsyncKeyState(VK_DOWN)) || (GetAsyncKeyState('W') and GetAsyncKeyState('S')) || (GetAsyncKeyState(VK_UP) and GetAsyncKeyState('S')) || (GetAsyncKeyState('W') and GetAsyncKeyState(VK_DOWN))) {
				MagnitudeY = 0;
			}
			if ((GetAsyncKeyState(VK_LEFT) and GetAsyncKeyState(VK_RIGHT)) || (GetAsyncKeyState('A') and GetAsyncKeyState('D')) || (GetAsyncKeyState(VK_LEFT) and GetAsyncKeyState('D')) || (GetAsyncKeyState('A') and GetAsyncKeyState(VK_RIGHT))) {
				MagnitudeX = 0;
			}
		}

		if (GetAsyncKeyState(VK_ESCAPE)) {
			HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
			SetConsoleTextAttribute(hConsole, 7);
			GameEngineSetup.GamePause();
		}


		// Collision of Player and Enemy
		if (myGameObject[0] != nullptr) {
			for (int i = 1; i < 5; i++) {
				if (myGameObject[i] != nullptr) {
					bool temp = map->CollisionPlayerandEnemies(myGameObject[0]->GetX(), myGameObject[0]->GetY(), myGameObject[i]->GetX(), myGameObject[i]->GetY());
					if (temp) {
						delete myGameObject[i];
						myGameObject[i] = nullptr;
						myGameObject[0]->DecreaseHealth();
					}
				}
			}
		}

		//delete all bullets when transitting
		if (changemap == true) {
			for (int i = 0; i < numberofbullets; i++) {
				if (BulletObject[i] != nullptr) {
					map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, -1, ' ');
					delete BulletObject[i];
					BulletObject[i] = nullptr;
				}
			}

			// Prevent Enemy Spawning in the walls + spawn enemy when defeated
			for (int i = 1; i < 5; i++) {
				if (myGameObject[i] == nullptr) {
					myGameObject[i] = new Enemy;
				}
			}

			if (myGameObject[1] != nullptr) {
				while (true) {
					e1randX1 = rand() % 40;
					e1randY1 = rand() % 20;
					myGameObject[1]->setXandY(e1randX1, e1randY1);
					if (map->CheckMap(myGameObject[1]->GetY(), myGameObject[1]->GetX()) == 0) {
						break;
					}
					else {
						continue;
					}
				}
			}

			if (myGameObject[2] != nullptr) {
				while (true) {
					e1randX2 = rand() % 40;
					e1randY2 = rand() % 20;
					myGameObject[2]->setXandY(e1randX2, e1randY2);
					if (map->CheckMap(myGameObject[2]->GetY(), myGameObject[2]->GetX()) == 0) {
						break;
					}
					else {
						continue;
					}
				}
			}

			if (myGameObject[3] != nullptr) {
				while (true) {
					e1randX3 = rand() % 40;
					e1randY3 = rand() % 20;
					myGameObject[3]->setXandY(e1randX3, e1randY3);
					if (map->CheckMap(myGameObject[3]->GetY(), myGameObject[3]->GetX()) == 0) {
						break;
					}
					else {
						continue;
					}
				}
			}

			if (myGameObject[4] != nullptr) {
				while (true) {
					e1randX4 = rand() % 40;
					e1randY4 = rand() % 20;
					myGameObject[4]->setXandY(e1randX4, e1randY4);
					if (map->CheckMap(myGameObject[4]->GetY(), myGameObject[4]->GetX()) == 0) {
						break;
					}
					else {
						continue;
					}
				}
			}
			changemap = false;
		}

		if (myGameObject[0] != nullptr) {
			if ((myGameObject[0]->GetX() < 2) || (myGameObject[0]->GetX() > 39) || (myGameObject[0]->GetY() < 2) || (myGameObject[0]->GetY() > 18)) {
				canshoot = false;
			}
			else {
				canshoot = true;
			}
		}

		//regenerate bullets
		if ((Update % 6 == 0) && (clip <= numberofbullets)) {
			clip++;
		}


		if (Artifact1 == true) {
			numberofbullets = 5;
		}

		if (Artifact2 == true) {
			firerate = 5;
		}

		//spawn the arrow
		if (myGameObject[0] != nullptr) {
			if ((clip > 0) && (Update % firerate == 0)) {
				if ((GetAsyncKeyState(VK_SPACE)) && (canshoot == true)) {
					for (int i = 0; i < numberofbullets; i++) {
						if (BulletObject[i] == nullptr) {
							if ((BDirection == 1) && (myGameObject[0]->GetY() != 0) && (map->CollisionY(myGameObject[0]->GetX(), myGameObject[0]->GetY(), -1) == 0)) {
								BulletObject[i] = new Bullets;
								BulletObject[i]->setBulletSymbol(1);
								BulletObject[i]->setOldPosition(myGameObject[0]->GetX(), myGameObject[0]->GetY() - 1);
								map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, -1, BulletObject[i]->getSymbol());
								BulletObject[i]->setOldPosition(myGameObject[0]->GetX(), myGameObject[0]->GetY() - 1);
								BulletObject[i]->setBulletDirection(1);
							}
							else if ((BDirection == 2) && (myGameObject[0]->GetY() != 40) && (map->CollisionY(myGameObject[0]->GetX(), myGameObject[0]->GetY(), 1) == 0)) {
								BulletObject[i] = new Bullets;
								BulletObject[i]->setBulletSymbol(1);
								BulletObject[i]->setOldPosition(myGameObject[0]->GetX(), myGameObject[0]->GetY() + 1);
								map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, 1, BulletObject[i]->getSymbol());
								BulletObject[i]->setOldPosition(myGameObject[0]->GetX(), myGameObject[0]->GetY() + 1);
								BulletObject[i]->setBulletDirection(2);
							}
							else if ((BDirection == 3) && (myGameObject[0]->GetX() != 0) && (map->CollisionX(myGameObject[0]->GetX(), myGameObject[0]->GetY(), -1) == 0)) {
								BulletObject[i] = new Bullets;
								BulletObject[i]->setBulletSymbol(2);
								BulletObject[i]->setOldPosition(myGameObject[0]->GetX() - 1, myGameObject[0]->GetY());
								map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), -1, 0, BulletObject[i]->getSymbol());
								BulletObject[i]->setOldPosition(myGameObject[0]->GetX() - 1, myGameObject[0]->GetY());
								BulletObject[i]->setBulletDirection(3);
							}
							else if ((BDirection == 4) && (myGameObject[0]->GetX() != 20) && (map->CollisionX(myGameObject[0]->GetX(), myGameObject[0]->GetY(), 1) == 0)) {
								BulletObject[i] = new Bullets;
								BulletObject[i]->setBulletSymbol(2);
								BulletObject[i]->setOldPosition(myGameObject[0]->GetX() + 1, myGameObject[0]->GetY());
								map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 1, 0, BulletObject[i]->getSymbol());
								BulletObject[i]->setOldPosition(myGameObject[0]->GetX() + 1, myGameObject[0]->GetY());
								BulletObject[i]->setBulletDirection(4);
							}
							break;
						}
					}
				}
				clip--;
			}
		}

		/*if bullet hits enemy, delete bullet*/
		for (int i = 0; i < numberofbullets; i++) {
			if (BulletObject[i] != nullptr) {
				if (BulletObject[i]->getBulletDIrection() == 1) {
					if (map->BulletCollisionY(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), -1, BulletObject[i]->getSymbol()) == 2) {
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, -1, BulletObject[i]->getSymbol());
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, -1, ' ');
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy() - 1, 0, -1, ' ');
						delete BulletObject[i];
						BulletObject[i] = nullptr;
						hitentity = true;
					}
				}
				else if (BulletObject[i]->getBulletDIrection() == 2) {
					if (map->BulletCollisionY(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 1, BulletObject[i]->getSymbol()) == 2) {
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, 1, BulletObject[i]->getSymbol());
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, 1, ' ');
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy() + 1, 0, 1, ' ');
						delete BulletObject[i];
						BulletObject[i] = nullptr;
						hitentity = true;
					}
				}
				else if (BulletObject[i]->getBulletDIrection() == 3) {
					if (map->BulletCollisionX(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), -1, BulletObject[i]->getSymbol()) == 2) {
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), -1, 0, BulletObject[i]->getSymbol());
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), -1, 0, ' ');
						map->DrawEntities(BulletObject[i]->getOldX() - 1, BulletObject[i]->getOldy(), -1, 0, ' ');
						delete BulletObject[i];
						BulletObject[i] = nullptr;
						hitentity = true;
					}
				}
				else if (BulletObject[i]->getBulletDIrection() == 4) {
					if (map->BulletCollisionX(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 1, BulletObject[i]->getSymbol()) == 2) {
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 1, 0, BulletObject[i]->getSymbol());
						map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 1, 0, ' ');
						map->DrawEntities(BulletObject[i]->getOldX() + 1, BulletObject[i]->getOldy(), 1, 0, ' ');
						delete BulletObject[i];
						BulletObject[i] = nullptr;
						hitentity = true;
					}
				}
			}
		}

		//check entity health
		if (hitentity == true) {
			for (int i = 1; i < 5; i++) {
				if (myGameObject[i] != nullptr) {
					if ((map->CheckMap(myGameObject[i]->GetY(), myGameObject[i]->GetX())) != 2) {
						if (myGameObject[i]->gethealth() != 0) {
							myGameObject[i]->DecreaseHealth();
							map->DrawEntities(myGameObject[i]->GetX(), myGameObject[i]->GetY(), 0, 0, myGameObject[i]->GetName());
						}
						if (myGameObject[i]->gethealth() == 0) {
							map->removebullets(myGameObject[i]->GetX(), myGameObject[i]->GetY());
							delete myGameObject[i];
							myGameObject[i] = nullptr;
						}
					}
				}
			}
			//for boss entity
			for (int i = 5; i < 9; i++) {
				if (myGameObject[i] != nullptr) {
					if ((map->CheckMap(myGameObject[i]->GetY(), myGameObject[i]->GetX())) != 2 and !Triggers3) {
						if (myGameObject[i]->gethealth() != 0) {
							myGameObject[i]->DecreaseHealth();
							map->DrawEntities(myGameObject[i]->GetX(), myGameObject[i]->GetY(), 0, 0, myGameObject[i]->GetName());
						}
						if (myGameObject[i]->gethealth() == 0) {
							SpawnMapBoss3 = false;
							map->SetMapE1(false);
							map->removebullets(myGameObject[i]->GetX(), myGameObject[i]->GetY());
							if (i == 5) {
								Artifact1 = true;
							}
							else if (i == 6) {
								Artifact2 = true;
							}
							else if (i == 7) {
								Artifact3 = true;
							}
							else if (i == 8) {
								Artifact4 = true;
							}
							delete myGameObject[i];
							myGameObject[i] = nullptr;
						}
					}
				}
			}
			//for final boss
			if (myGameObject[9] != nullptr) {
				if ((map->CheckMap(myGameObject[9]->GetY(), myGameObject[9]->GetX())) != 2) {
					if (myGameObject[9]->gethealth() != 0) {
						myGameObject[9]->DecreaseHealth();
						map->DrawEntities(myGameObject[9]->GetX(), myGameObject[9]->GetY(), 0, 0, myGameObject[9]->GetName());
					}
					if (myGameObject[9]->gethealth() == 0) {
						map->SetMapE1(false);
						map->removebullets(myGameObject[9]->GetX(), myGameObject[9]->GetY());
						delete myGameObject[9];
			     		myGameObject[9] = nullptr;
						FinalBossDefeated = true;
				    }
				}
			}
		}

		//update bullet
		if (hitentity == false) {
			for (int i = 0; i < numberofbullets; i++) {
				if (BulletObject[i] != nullptr) {
					if (BulletObject[i]->getBulletDIrection() == 1) {
						if (map->BulletCollisionY(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), -1, BulletObject[i]->getSymbol()) == 0) {
							map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, -1, BulletObject[i]->getSymbol());
							BulletObject[i]->setOldPosition(BulletObject[i]->getOldX(), BulletObject[i]->getOldy() - 1);
						}
						else {
							map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, -1, BulletObject[i]->getSymbol());
							map->removebullets(BulletObject[i]->getOldX(), BulletObject[i]->getOldy());
							delete BulletObject[i];
							BulletObject[i] = nullptr;
						}
					}
					else if (BulletObject[i]->getBulletDIrection() == 2) {
						if ((map->BulletCollisionY(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 1, BulletObject[i]->getSymbol()) == 0) && (BulletObject[i]->getOldy() != 20)) {
							map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, 1, BulletObject[i]->getSymbol());
							BulletObject[i]->setOldPosition(BulletObject[i]->getOldX(), BulletObject[i]->getOldy() + 1);
						}
						else {
							map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 0, 1, BulletObject[i]->getSymbol());
							map->removebullets(BulletObject[i]->getOldX(), BulletObject[i]->getOldy());
							delete BulletObject[i];
							BulletObject[i] = nullptr;
						}
					}
					else if (BulletObject[i]->getBulletDIrection() == 3) {
						if (map->BulletCollisionX(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), -1, BulletObject[i]->getSymbol()) == 0) {
							map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), -1, 0, BulletObject[i]->getSymbol());
							BulletObject[i]->setOldPosition(BulletObject[i]->getOldX() - 1, BulletObject[i]->getOldy());
						}
						else {
							map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), -1, 0, BulletObject[i]->getSymbol());
							map->removebullets(BulletObject[i]->getOldX(), BulletObject[i]->getOldy());
							delete BulletObject[i];
							BulletObject[i] = nullptr;
						}
					}
					else {
						if ((map->BulletCollisionX(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 1, BulletObject[i]->getSymbol()) == 0) && (BulletObject[i]->getOldX() != 40)) {
							map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 1, 0, BulletObject[i]->getSymbol());
							BulletObject[i]->setOldPosition(BulletObject[i]->getOldX() + 1, BulletObject[i]->getOldy());
						}
						else {
							map->DrawEntities(BulletObject[i]->getOldX(), BulletObject[i]->getOldy(), 1, 0, BulletObject[i]->getSymbol());
							map->removebullets(BulletObject[i]->getOldX(), BulletObject[i]->getOldy());
							delete BulletObject[i];
							BulletObject[i] = nullptr;
						}
					}
				}
			}
		}
		hitentity = false;

		Artifact1 = true;
		Artifact2 = true;
		Artifact3 = true;
		Artifact4 = true;
//Final Boss
		//spawn final boss
		if ((Artifact1 == true) && (Artifact2 == true) && (Artifact3 == true) && (Artifact4 == true) && (MapTransit == "C3Normal") && (FinalBossDefeated == false)) {
			if (Spawnfinalboss == true) {
				myGameObject[9] = new FinalBoss;
				Spawnfinalboss = false;
				myGameObject[9]->sethealth(5);
				map->DrawEntities(20, 10, 0, 0, myGameObject[9]->GetName());
			}
			if (myGameObject[9] != nullptr) {
				if (Update % 5 == 0) {
					static_cast<FinalBoss*>(myGameObject[9])->playertracking((myGameObject[0]->GetX()), (myGameObject[0]->GetY()));
					myGameObject[9]->moveX(myGameObject[9]->GetX(), bossX);
					myGameObject[9]->moveY(myGameObject[9]->GetY(), bossY);
				}
			}
			for (int i = 1; i < 5; i++) {
				if (myGameObject[i] != nullptr) {
					map->DrawEntities(myGameObject[i]->GetX(), myGameObject[i]->GetY(), 0, -1, ' ');
					delete myGameObject[i];
					myGameObject[i] = nullptr;
				}
			}
			map->DrawEntities(myGameObject[9]->GetX(), myGameObject[9]->GetY(), bossX, bossY, myGameObject[9]->GetName());
			FinalBossUpdate++;
		}
		//spawn the boss arrow
		if(myGameObject[9] != nullptr){
			if (FinalBossUpdate % 7 == 0) {
				for (int i = 0; i < 7; i++) {
					BBDirection = rand() % 4 + 1;
					if (BossBulletObject[i] == nullptr) {
						if ((BBDirection == 1) && (myGameObject[9]->GetY() != 0) && (map->CollisionY(myGameObject[9]->GetX(), myGameObject[9]->GetY(), -1) == 0)) {
							BossBulletObject[i] = new Bullets;
							BossBulletObject[i]->setBulletSymbol(1);
							BossBulletObject[i]->setOldPosition(myGameObject[9]->GetX(), myGameObject[9]->GetY() - 1);
							map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 0, -1, BossBulletObject[i]->getSymbol());
							BossBulletObject[i]->setOldPosition(myGameObject[9]->GetX(), myGameObject[9]->GetY() - 1);
							BossBulletObject[i]->setBulletDirection(1);
						}
						else if ((BBDirection == 2) && (myGameObject[9]->GetY() != 40) && (map->CollisionY(myGameObject[9]->GetX(), myGameObject[9]->GetY(), 1) == 0)) {
							BossBulletObject[i] = new Bullets;
							BossBulletObject[i]->setBulletSymbol(1);
							BossBulletObject[i]->setOldPosition(myGameObject[9]->GetX(), myGameObject[9]->GetY() + 1);
							map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 0, 1, BossBulletObject[i]->getSymbol());
							BossBulletObject[i]->setOldPosition(myGameObject[9]->GetX(), myGameObject[9]->GetY() + 1);
							BossBulletObject[i]->setBulletDirection(2);
						}
						else if ((BBDirection == 3) && (myGameObject[9]->GetX() != 0) && (map->CollisionX(myGameObject[9]->GetX(), myGameObject[9]->GetY(), -1) == 0)) {
							BossBulletObject[i] = new Bullets;
							BossBulletObject[i]->setBulletSymbol(2);
							BossBulletObject[i]->setOldPosition(myGameObject[9]->GetX() - 1, myGameObject[9]->GetY());
							map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), -1, 0, BossBulletObject[i]->getSymbol());
							BossBulletObject[i]->setOldPosition(myGameObject[9]->GetX() - 1, myGameObject[9]->GetY());
							BossBulletObject[i]->setBulletDirection(3);
						}
						else if ((BBDirection == 4) && (myGameObject[9]->GetX() != 20) && (map->CollisionX(myGameObject[9]->GetX(), myGameObject[9]->GetY(), 1) == 0)) {
							BossBulletObject[i] = new Bullets;
							BossBulletObject[i]->setBulletSymbol(2);
							BossBulletObject[i]->setOldPosition(myGameObject[9]->GetX() + 1, myGameObject[9]->GetY());
							map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 1, 0, BossBulletObject[i]->getSymbol());
							BossBulletObject[i]->setOldPosition(myGameObject[9]->GetX() + 1, myGameObject[9]->GetY());
							BossBulletObject[i]->setBulletDirection(4);
						}
					}
					break;
				}
			}

			/*if bullet hits Player, delete bullet*/
			for (int i = 0; i < 7; i++) {
				if (BossBulletObject[i] != nullptr) {
					if (BossBulletObject[i]->getBulletDIrection() == 1) {
						if (map->BulletCollisionY(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), -1, BossBulletObject[i]->getSymbol()) == 3) {
							map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 0, -1, BossBulletObject[i]->getSymbol());
							map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 0, -1, ' ');
							map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy() - 1, 0, -1, ' ');
							delete BossBulletObject[i];
							BossBulletObject[i] = nullptr;
							hitentity = true;
						}
					}
					else if (BossBulletObject[i]->getBulletDIrection() == 2) {
						if (map->BulletCollisionY(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 1, BossBulletObject[i]->getSymbol()) == 3) {
							map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 0, 1, BossBulletObject[i]->getSymbol());
							map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 0, 1, ' ');
							map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy() + 1, 0, 1, ' ');
							delete BossBulletObject[i];
							BossBulletObject[i] = nullptr;
							hitentity = true;
						}
					}
					else if (BossBulletObject[i]->getBulletDIrection() == 3) {
						if (map->BulletCollisionX(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), -1, BossBulletObject[i]->getSymbol()) == 3) {
							map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), -1, 0, BossBulletObject[i]->getSymbol());
							map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), -1, 0, ' ');
							map->DrawEntities(BossBulletObject[i]->getOldX() - 1, BossBulletObject[i]->getOldy(), -1, 0, ' ');
							delete BossBulletObject[i];
							BossBulletObject[i] = nullptr;
							hitentity = true;
						}
					}
					else if (BossBulletObject[i]->getBulletDIrection() == 4) {
						if (map->BulletCollisionX(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 1, BossBulletObject[i]->getSymbol()) == 3) {
							map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 1, 0, BossBulletObject[i]->getSymbol());
							map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 1, 0, ' ');
							map->DrawEntities(BossBulletObject[i]->getOldX() + 1, BossBulletObject[i]->getOldy(), 1, 0, ' ');
							delete BossBulletObject[i];
							BossBulletObject[i] = nullptr;
							hitentity = true;
						}
					}
				}
			}
			//check Player health
			if (hitentity == true) {
				if (myGameObject[0] != nullptr) {
					if ((map->CheckMap(myGameObject[0]->GetY(), myGameObject[0]->GetX())) != 3) {
						if (myGameObject[0]->gethealth() != 0) {
							myGameObject[0]->DecreaseHealth();
							map->DrawEntities(myGameObject[0]->GetX(), myGameObject[0]->GetY(), 0, 0, myGameObject[0]->GetName());
						}
						if (myGameObject[0]->gethealth() == 0) {
							map->removebullets(myGameObject[0]->GetX(), myGameObject[0]->GetY());
						}
					}
				}
			}

			//update Boss bullet
			if (hitentity == false) {
				for (int i = 0; i < 7; i++) {
					if (BossBulletObject[i] != nullptr) {
						if (BossBulletObject[i]->getBulletDIrection() == 1) {
							if (map->BulletCollisionY(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), -1, BossBulletObject[i]->getSymbol()) == 0) {
								map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 0, -1, BossBulletObject[i]->getSymbol());
								BossBulletObject[i]->setOldPosition(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy() - 1);
							}
							else {
								map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 0, -1, BossBulletObject[i]->getSymbol());
								map->removebullets(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy());
								delete BossBulletObject[i];
								BossBulletObject[i] = nullptr;
							}
						}
						else if (BossBulletObject[i]->getBulletDIrection() == 2) {
							if ((map->BulletCollisionY(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 1, BossBulletObject[i]->getSymbol()) == 0) && (BossBulletObject[i]->getOldy() != 20)) {
								map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 0, 1, BossBulletObject[i]->getSymbol());
								BossBulletObject[i]->setOldPosition(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy() + 1);
							}
							else {
								map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 0, 1, BossBulletObject[i]->getSymbol());
								map->removebullets(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy());
								delete BossBulletObject[i];
								BossBulletObject[i] = nullptr;
							}
						}
						else if (BossBulletObject[i]->getBulletDIrection() == 3) {
							if (map->BulletCollisionX(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), -1, BossBulletObject[i]->getSymbol()) == 0) {
								map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), -1, 0, BossBulletObject[i]->getSymbol());
								BossBulletObject[i]->setOldPosition(BossBulletObject[i]->getOldX() - 1, BossBulletObject[i]->getOldy());
							}
							else {
								map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), -1, 0, BossBulletObject[i]->getSymbol());
								map->removebullets(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy());
								delete BossBulletObject[i];
								BossBulletObject[i] = nullptr;
							}
						}
						else {
							if ((map->BulletCollisionX(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 1, BossBulletObject[i]->getSymbol()) == 0) && (BossBulletObject[i]->getOldX() != 40)) {
								map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 1, 0, BossBulletObject[i]->getSymbol());
								BossBulletObject[i]->setOldPosition(BossBulletObject[i]->getOldX() + 1, BossBulletObject[i]->getOldy());
							}
							else {
								map->DrawEntities(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy(), 1, 0, BossBulletObject[i]->getSymbol());
								map->removebullets(BossBulletObject[i]->getOldX(), BossBulletObject[i]->getOldy());
								delete BossBulletObject[i];
								BossBulletObject[i] = nullptr;
							}
						}
					}
				}
			}
			hitentity = false;
		}
		
		//Collision of the '#'
		if (myGameObject[0] != nullptr) {
			if (map->CollisionX(myGameObject[0]->GetX(), myGameObject[0]->GetY(), MagnitudeX)) {
				MagnitudeX = 0;
				canshoot = false;
			}
			else
				canshoot = true;
			if (map->CollisionY(myGameObject[0]->GetX(), myGameObject[0]->GetY(), MagnitudeY)) {
				MagnitudeY = 0;
				canshoot = false;
			}
			else
				canshoot = true;
		}

		// Movement of Enemy
		if (myGameObject[1] != nullptr) {
			if (map->CollisionX(myGameObject[1]->GetX(), myGameObject[1]->GetY(), x1)) {
				x1 = 0;
			}
			if (map->CollisionY(myGameObject[1]->GetX(), myGameObject[1]->GetY(), y1)) {
				y1 = 0;
			}
			if (Update % 5 == 0) {
				myGameObject[1]->moveX(myGameObject[1]->GetX(), x1);
				myGameObject[1]->moveY(myGameObject[1]->GetY(), y1);
			}
			map->DrawEntities(myGameObject[1]->GetX(), myGameObject[1]->GetY(), x1, y1, myGameObject[1]->GetName());
		}

		if (myGameObject[2] != nullptr) {
			if (map->CollisionX(myGameObject[2]->GetX(), myGameObject[2]->GetY(), x2)) {
				x2 = 0;
			}
			if (map->CollisionY(myGameObject[2]->GetX(), myGameObject[2]->GetY(), y2)) {
				y2 = 0;
			}
			if (Update % 5 == 0) {
				myGameObject[2]->moveX(myGameObject[2]->GetX(), x2);
				myGameObject[2]->moveY(myGameObject[2]->GetY(), y2);
			}
			map->DrawEntities(myGameObject[2]->GetX(), myGameObject[2]->GetY(), x2, y2, myGameObject[2]->GetName());
		}


		if (myGameObject[3] != nullptr) {
			if (map->CollisionX(myGameObject[3]->GetX(), myGameObject[3]->GetY(), x3)) {
				x3 = 0;
			}
			if (map->CollisionY(myGameObject[3]->GetX(), myGameObject[3]->GetY(), y3)) {
				y3 = 0;
			}
			if (Update % 5 == 0) {
				myGameObject[3]->moveX(myGameObject[3]->GetX(), x3);
				myGameObject[3]->moveY(myGameObject[3]->GetY(), y3);
			}
			map->DrawEntities(myGameObject[3]->GetX(), myGameObject[3]->GetY(), x3, y3, myGameObject[3]->GetName());
		}


		if (myGameObject[4] != nullptr) {
			if (map->CollisionX(myGameObject[4]->GetX(), myGameObject[4]->GetY(), x4)) {
				x4 = 0;
			}
			if (map->CollisionY(myGameObject[4]->GetX(), myGameObject[4]->GetY(), y4)) {
				y4 = 0;
			}
			if (Update % 5 == 0) {
				myGameObject[4]->moveX(myGameObject[4]->GetX(), x4);
				myGameObject[4]->moveY(myGameObject[4]->GetY(), y4);
			}
			map->DrawEntities(myGameObject[4]->GetX(), myGameObject[4]->GetY(), x4, y4, myGameObject[4]->GetName());
		}

		// still testing of spawning of boss
		if (myGameObject[0] != nullptr) {
			if (MapTransit == "E1" and SpawnMapBoss3 == true) {
				if (map->TriggerWallBossandPlayer(myGameObject[0]->GetY(), myGameObject[0]->GetX(), "E1") == true and Triggers3) {
					map->SetMapE1(true);
					Triggers3 = false;
					allowBosstoMove3 = true;
					for (int i = 1; i < 5; i++) {
						if (myGameObject[i] != nullptr) {
							delete myGameObject[i];
							myGameObject[i] = nullptr;
						}
					}
				}
				if (myGameObject[5] == nullptr) {
					myGameObject[5] = new Boss;
					myGameObject[5]->setXandY(8, 15);
					myGameObject[5]->sethealth(5);
				}

				if (allowBosstoMove3 == true) {
					if (myGameObject[5] != nullptr) {
						if (Update % 5 == 0) {
							static_cast<Boss*>(myGameObject[5])->playertracking((myGameObject[0]->GetX()), (myGameObject[0]->GetY()));
							myGameObject[5]->moveX(myGameObject[5]->GetX(), bossX);
							myGameObject[5]->moveY(myGameObject[5]->GetY(), bossY);
						}
					}
				}
				map->DrawEntities(myGameObject[5]->GetX(), myGameObject[5]->GetY(), bossX, bossY, myGameObject[5]->GetName());
			}
		}

		// Movement and spawnning of entities
		if (myGameObject[0] != nullptr) {
			myGameObject[0]->moveX(myGameObject[0]->GetX(), MagnitudeX);
			myGameObject[0]->moveY(myGameObject[0]->GetY(), MagnitudeY);
			map->DrawEntities(myGameObject[0]->GetX(), myGameObject[0]->GetY(), MagnitudeX, MagnitudeY, myGameObject[0]->GetName());
		}


		//Map Number A2 to A3
		if (myGameObject[0] != nullptr) {
			for (int i = 2; i <= 11; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "A2" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "A3";
					changemap = true;
				}
			}

			//Map Number A3 to A2
			for (int i = 2; i <= 11; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "A3" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "A2";
					changemap = true;
				}
			}

			//Map Number A3 to A4
			for (int i = 2; i <= 11; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "A3" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "A4";
					changemap = true;
				}
			}

			//Map Number A4 to A3
			for (int i = 2; i <= 11; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "A4" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "A3";
					changemap = true;
				}
			}

			//Map Number A4 to A5
			for (int i = 2; i <= 16; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "A4" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "A5";
					changemap = true;
				}
			}

			//Map Number A5 to A4
			for (int i = 2; i <= 16; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "A5" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "A4";
					changemap = true;
				}
			}

			//Map Number A1 to A2
			for (int i = 2; i <= 11; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "A1" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "A2";
					changemap = true;
				}
			}

			//Map Number A2 to A1
			for (int i = 2; i <= 11; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "A2" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "A1";
					changemap = true;
				}
			}

			//Map Number B1 to A1
			for (int i = 2; i <= 23; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "B1" and (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W'))) {
					myGameObject[0]->setXandY(i, 19);
					Access = true;
					MapTransit = "A1";
					changemap = true;
				}
			}

			//Map Number A1 to B1
			for (int i = 2; i <= 23; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "A1" and (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S'))) {
					myGameObject[0]->setXandY(i, 1);
					Access = true;
					MapTransit = "B1";
					changemap = true;
				}
			}


			//Map Number B2 to A2
			for (int i = 17; i <= 35; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "B2" and (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W'))) {
					myGameObject[0]->setXandY(i, 19);
					Access = true;
					MapTransit = "A2";
					changemap = true;
				}
			}

			//Map Number A2 to B2
			for (int i = 17; i <= 35; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "A2" and (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S'))) {
					myGameObject[0]->setXandY(i, 1);
					Access = true;
					MapTransit = "B2";
					changemap = true;
				}
			}


			//Map Number B3 to A3
			for (int i = 15; i <= 25; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "B3" and (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W'))) {
					myGameObject[0]->setXandY(i, 19);
					Access = true;
					MapTransit = "A3";
					changemap = true;
				}
			}

			//Map Number A3 to B3
			for (int i = 15; i <= 25; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "A3" and (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S'))) {
					myGameObject[0]->setXandY(i, 1);
					Access = true;
					MapTransit = "B3";
					changemap = true;
				}
			}

			//Map Number B4 to A4
			for (int i = 15; i <= 25; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "B4" and (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W'))) {
					myGameObject[0]->setXandY(i, 19);
					Access = true;
					MapTransit = "A4";
					changemap = true;
				}
			}

			//Map Number A4 to B4
			for (int i = 15; i <= 25; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "A4" and (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S'))) {
					myGameObject[0]->setXandY(i, 1);
					Access = true;
					MapTransit = "B4";
					changemap = true;
				}
			}

			//Map Number B5 to A5
			for (int i = 15; i <= 38; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "B5" and (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W'))) {
					myGameObject[0]->setXandY(i, 19);
					Access = true;
					MapTransit = "A5";
					changemap = true;
				}
			}

			//Map Number A5 to B5
			for (int i = 15; i <= 38; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "A5" and (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S'))) {
					myGameObject[0]->setXandY(i, 1);
					Access = true;
					MapTransit = "B5";
					changemap = true;
				}
			}
			//Map Number B1 to B2
			for (int i = 9; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "B1" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "B2";
					changemap = true;
				}
			}

			//Map Number B2 to B1
			for (int i = 9; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "B2" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					changemap = true;
					MapTransit = "B1";
				}
			}

			//Map Number B2 to B3
			for (int i = 2; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "B2" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "B3";
					changemap = true;
				}
			}

			//Map Number B3 to B2
			for (int i = 2; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "B3" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "B2";
					changemap = true;
				}
			}

			//Map Number B3 to B4
			for (int i = 2; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "B3" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "B4";
					changemap = true;
				}
			}

			//Map Number B4 to B3
			for (int i = 2; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "B4" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "B3";
					changemap = true;
				}
			}


			//Map Number B4 to B5
			for (int i = 2; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "B4" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "B5";
					changemap = true;
				}
			}

			//Map Number B5 to B4
			for (int i = 2; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "B5" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "B4";
					changemap = true;
				}
			}


			//Map Number C1 to B1
			for (int i = 2; i <= 8; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "C1" and (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W'))) {
					myGameObject[0]->setXandY(i, 19);
					Access = true;
					MapTransit = "B1";
					changemap = true;
				}
			}

			//Map Number B1 to C1
			for (int i = 2; i <= 8; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "B1" and (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S'))) {
					myGameObject[0]->setXandY(i, 1);
					Access = true;
					MapTransit = "C1";
					changemap = true;
				}
			}



			//Map Number C3Normal to B3
			for (int i = 15; i <= 25; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "C3Normal" and (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W'))) {
					myGameObject[0]->setXandY(i, 19);
					Access = true;
					MapTransit = "B3";
					changemap = true;
				}
			}

			//Map Number B3 to C3Normal
			for (int i = 15; i <= 25; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "B3" and (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S'))) {
					myGameObject[0]->setXandY(i, 1);
					Access = true;
					MapTransit = "C3Normal";
					changemap = true;
				}
			}


			//Map Number C2 to C1
			for (int i = 8; i <= 12; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "C2" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "C1";
					changemap = true;
				}
			}


			//Map Number C1 to C2
			for (int i = 8; i <= 12; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "C1" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "C2";
					changemap = true;
				}
			}



			//Map Number C5 to C4
			for (int i = 8; i <= 12; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "C5" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "C4";
					changemap = true;
				}
			}


			//Map Number C4 to C5
			for (int i = 8; i <= 12; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "C4" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "C5";
					changemap = true;
				}
			}



			//Map Number C3Normal to C2
			for (int i = 8; i <= 12; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "C3Normal" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "C2";
					changemap = true;
				}
			}


			//Map Number C2 to C3Normal
			for (int i = 8; i <= 12; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "C2" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "C3Normal";
					changemap = true;
				}
			}

			//Map Number C3Normal to C4
			for (int i = 8; i <= 12; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "C3Normal" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "C4";
					changemap = true;
				}
			}


			//Map Number C4 to C3Normal
			for (int i = 8; i <= 12; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "C4" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "C3Normal";
					changemap = true;
				}
			}



			//Map Number D5 to C5
			for (int i = 32; i <= 38; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "D5" and (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W'))) {
					myGameObject[0]->setXandY(i, 19);
					Access = true;
					MapTransit = "C5";
					changemap = true;
				}
			}

			//Map Number C5 to D5
			for (int i = 32; i <= 38; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "C5" and (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S'))) {
					myGameObject[0]->setXandY(i, 1);
					Access = true;
					MapTransit = "D5";
					changemap = true;
				}
			}


			//Map Number C5 to B5
			for (int i = 32; i <= 38; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "C5" and (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W'))) {
					myGameObject[0]->setXandY(i, 19);
					Access = true;
					MapTransit = "B5";
					changemap = true;
				}
			}

			//Map Number B5 to C5
			for (int i = 32; i <= 38; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "B5" and (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S'))) {
					myGameObject[0]->setXandY(i, 1);
					Access = true;
					MapTransit = "C5";
					changemap = true;
				}
			}

			//Map Number E4 to D4
			for (int i = 5; i <= 25; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "E4" and (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W'))) {
					myGameObject[0]->setXandY(i, 19);
					Access = true;
					changemap = true;
					MapTransit = "D4";
				}
			}

			//Map Number D4 to E4
			for (int i = 5; i <= 25; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "D4" and (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S'))) {
					myGameObject[0]->setXandY(i, 1);
					Access = true;
					MapTransit = "E4";
					changemap = true;
				}
			}


			//Map Number D1 to D2
			for (int i = 2; i <= 12; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "D1" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					changemap = true;
					MapTransit = "D2";
				}
			}

			//Map Number D2 to D1
			for (int i = 2; i <= 12; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "D2" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "D1";
					changemap = true;
				}
			}


			//Map Number D1 to C1
			for (int i = 2; i <= 8; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "D1" and (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W'))) {
					myGameObject[0]->setXandY(i, 19);
					Access = true;
					MapTransit = "C1";
					changemap = true;
				}
			}

			//Map Number C1 to D1
			for (int i = 2; i <= 8; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "C1" and (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S'))) {
					myGameObject[0]->setXandY(i, 1);
					Access = true;
					MapTransit = "D1";
					changemap = true;
				}
			}


			//Map Number E3 to D3
			for (int i = 15; i <= 25; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "E3" and (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W'))) {
					myGameObject[0]->setXandY(i, 19);
					Access = true;
					MapTransit = "D3";
					changemap = true;
				}
			}

			//Map Number D3 to E3
			for (int i = 15; i <= 25; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "D3" and (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S'))) {
					myGameObject[0]->setXandY(i, 1);
					Access = true;
					MapTransit = "E3";
					changemap = true;
				}
			}

			//Map Number D2 to D3
			for (int i = 2; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "D2" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "D3";
					changemap = true;
				}
			}

			//Map Number D3 to D4
			for (int i = 2; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "D3" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "D4";
					changemap = true;
				}
			}

			//Map Number D3 to C3Normal
			for (int i = 15; i <= 25; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "D3" and (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W'))) {
					myGameObject[0]->setXandY(i, 19);
					Access = true;
					MapTransit = "C3Normal";
					changemap = true;
				}
			}

			//Map Number C3Normal to D3
			for (int i = 15; i <= 25; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "C3Normal" and (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S'))) {
					myGameObject[0]->setXandY(i, 1);
					Access = true;
					MapTransit = "D3";
					changemap = true;
				}
			}

			//Map Number D3 to D2
			for (int i = 2; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "D3" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "D2";
					changemap = true;
				}
			}

			//Map Number D4 to D3
			for (int i = 2; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "D4" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "D3";
					changemap = true;
				}
			}


			//Map Number D4 to D5
			for (int i = 2; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "D4" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "D5";
					changemap = true;
				}
			}

			//Map Number D5 to D4
			for (int i = 2; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "D5" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "D4";
					changemap = true;
				}
			}


			//Map Number E1 to D1
			for (int i = 2; i <= 24; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "E1" and (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W'))) {
					myGameObject[0]->setXandY(i, 19);
					Access = true;
					MapTransit = "D1";
					changemap = true;
				}
			}

			//Map Number D1 to E1
			for (int i = 2; i <= 24; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "D1" and (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S'))) {
					myGameObject[0]->setXandY(i, 1);
					Access = true;
					MapTransit = "E1";
					changemap = true;
				}
			}


			//Map Number E2 to D2
			for (int i = 15; i <= 25; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "E2" and (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W'))) {
					myGameObject[0]->setXandY(i, 19);
					Access = true;
					MapTransit = "D2";
					changemap = true;
				}
			}

			//Map Number D2 to E2
			for (int i = 15; i <= 25; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "D2" and (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S'))) {
					myGameObject[0]->setXandY(i, 1);
					Access = true;
					MapTransit = "E2";
					changemap = true;
				}
			}

			// Map Number E1 to E2
			for (int i = 8; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "E1" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "E2";
					changemap = true;
				}
			}

			// Map Number E2 to E1
			for (int i = 8; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "E2" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "E1";
					changemap = true;
				}
			}

			// Map Number E3 to E2
			for (int i = 8; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "E3" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "E2";
					changemap = true;
				}
			}

			// Map Number E2 to E3
			for (int i = 8; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "E2" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "E3";
					changemap = true;
				}
			}

			// Map Number E3 to E4
			for (int i = 8; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "E3" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "E4";
					changemap = true;
				}
			}

			// Map Number E4 to E3
			for (int i = 8; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "E4" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					MapTransit = "E3";
					changemap = true;
				}
			}

			// Map Number E4 to E5
			for (int i = 8; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 39 and myGameObject[0]->GetY() == i and MapTransit == "E4" and (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D'))) {
					myGameObject[0]->setXandY(1, i);
					Access = true;
					MapTransit = "E5";
					changemap = true;
				}
			}

			// Map Number E5 to E4
			for (int i = 8; i <= 18; i++) {
				if (myGameObject[0]->GetX() == 1 and myGameObject[0]->GetY() == i and MapTransit == "E5" and (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A'))) {
					myGameObject[0]->setXandY(39, i);
					Access = true;
					changemap = true;
					MapTransit = "E4";
				}
			}

			//Map Number E5 to D5
			for (int i = 15; i <= 39; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 1 and MapTransit == "E5" and (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W'))) {
					myGameObject[0]->setXandY(i, 19);
					Access = true;
					MapTransit = "D5";
					changemap = true;
				}
			}

			//Map Number D5 to E5
			for (int i = 15; i <= 39; i++) {
				if (myGameObject[0]->GetX() == i and myGameObject[0]->GetY() == 19 and MapTransit == "D5" and (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S'))) {
					myGameObject[0]->setXandY(i, 1);
					Access = true;
					MapTransit = "E5";
					changemap = true;
				}
			}
		}
		Update++;
	}

	for (int i = 0; i < 6; i++) {
		if (myGameObject[i] != nullptr) {
			delete myGameObject[i];
			myGameObject[i] = nullptr;
		}
	}
	return 0;
}