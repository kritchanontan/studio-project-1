#include "FinalBoss.h"

FinalBoss::FinalBoss() {
	x = 20;
	y = 10;
	character = 'F';
}

void FinalBoss::moveX(int MoveX, int MagnitudeX)
{
	x = MoveX;
	x += MagnitudeX;

	if (x <= 0) {
		x = 1;
	}

	if (x >= 40) {
		x = 39;
	}
}

void FinalBoss::moveY(int MoveY, int MagnitudeY)
{
	y = MoveY;
	y += MagnitudeY;

	if (y <= 0) {
		y = 1;
	}
	if (y >= 20) {
		y = 19;
	}
}


void FinalBoss::setXandY(int NewX, int NewY)
{
	if (NewX > 0 and NewX < 40 and NewY > 0 and NewY < 20) {
		x = NewX;
		y = NewY;
	}
}

void FinalBoss::playertracking(int px, int py) {
	if (x < px) {
		x++;
	}
	else if (x > px) {
		x--;
	}
	else if (y < py) {
		y++;
	}
	else if (y > py) {
		y--;
	}
}

FinalBoss::~FinalBoss()
{
}
