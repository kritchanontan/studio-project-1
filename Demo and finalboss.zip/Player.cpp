#include "Player.h"

Player::Player()
{
	character = (char)219;
	health = 5;
}



void Player::moveX(int MoveX, int MagnitudeX)
{
	x = MoveX;
	x += MagnitudeX;

	if (x <= 0) {
		x = 1;
	}

	if (x >= 40) {
		x = 39;
	}
}

void Player::moveY(int MoveY, int MagnitudeY)
{
	y = MoveY;
	y += MagnitudeY;

	if (y <= 0) {
		y = 1;
	}
	if (y >= 20) {
		y = 19;
	}
}

void Player::setXandY(int NewX, int NewY)
{
	if (NewX > 0 and NewX < 40 and NewY > 0 and NewY < 20) {
		x = NewX;
		y = NewY;
	}
}

Player::~Player()
{
}