#include "Player.h"

Player::Player()
{
	character = 'V';
}
