#include "Map.h"
#include <Windows.h>
#include <iostream>
using namespace std;

void gotoxy(int x, int y) {
	COORD scrn;
	HANDLE hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	scrn.X = x; scrn.Y = y;
	SetConsoleCursorPosition(hConsoleOutput, scrn);
}

void Map::UpdatedMap()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			if ((i == 0 || i == 20) or (j == 0 || j == 40)) {
				MapSize[i][j] = '#';
			}
			else {
				MapSize[i][j] = ' ';
			}
			cout << MapSize[i][j];
		}
		cout << endl;
	}
}

void Map::DrawEntities(int PosX, int PosY, int MagnitudeX, int MagnitudeY, char name)
{ 
	gotoxy(PosX, PosY);
	cout << name;
	if (MagnitudeX == 1 and PosX <= 39) {
		PosX--;
		gotoxy(PosX, PosY);
		cout << ' ';
	}
	if (MagnitudeX == -1 and PosX >= 1) {
		PosX++;
		gotoxy(PosX, PosY);
		cout << ' ';
	}
	if (MagnitudeY == 1 and PosY <= 19) {
		PosY--;
		gotoxy(PosX, PosY);
		cout << ' ';
	}
	if (MagnitudeY == -1 and PosY >= 1) {
		PosY++;
		gotoxy(PosX, PosY);
		cout << ' ';
	}
	gotoxy(0, 21);
}
