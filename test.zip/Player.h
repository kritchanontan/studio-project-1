#pragma once
#include "Entities.h"

class Player : public Entities
{
private:
	char Bullets;
public:
	Player();
};

