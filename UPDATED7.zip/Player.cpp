#include "Player.h"

Player::Player()
{
	character = (char)219;
}
