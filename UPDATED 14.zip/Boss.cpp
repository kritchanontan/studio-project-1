#include "Boss.h"

Boss::Boss()
{
	x = 0;
	y = 0;
	character = 'B';
}

Boss::~Boss()
{
}

void Boss::moveX(int MoveX, int MagnitudeX)
{
	x = MoveX;
	x += MagnitudeX;

	if (x <= 0) {
		x = 1;
	}

	if (x >= 40) {
		x = 39;
	}
}

void Boss::moveY(int MoveY, int MagnitudeY)
{
	y = MoveY;
	y += MagnitudeY;

	if (y <= 0) {
		y = 1;
	}
	if (y >= 20) {
		y = 19;
	}
}

int Boss::BossXCheck(int x1, int x2)
{
	int x = 0;
	if (x1 > x2) {
		x++;
	}
	if (x1 < x2) {
		x--;
	}
	if (x1 == x2) {
		x = 0;
	}
	return x;
}

int Boss::BossYCheck(int y1, int y2)
{
	int y = 0;
	if (y1 > y2) {
		y++;
	}
	if (y1 < y2) {
		y--;
	}
	if (y1 == y2) {
		y = 0;
	}
	return y;
}

void Boss::setXandY(int NewX, int NewY)
{
	if (NewX > 0 and NewX < 40 and NewY > 0 and NewY < 20) {
		x = NewX;
		y = NewY;
	}
}