#pragma once

class Entities
{
protected:
	int x;
	int y;
	char character;
	int health;
public:
	Entities();
	virtual void moveX(int MoveX, int MagnitudeX) = 0;
	virtual void moveY(int MoveY, int MagnitudeY) = 0;
	void setName(char name);
	void sethealth(int x);
	char GetName() const;
	void DecreaseHealth();
	virtual void setXandY(int NewX, int NewY) = 0;
	int GetX() const;
	int GetY() const;
	int gethealth() const;
	~Entities();
};

