#pragma once
#include "Entities.h"

class Boss : public Entities
{
public:
	void moveX(int MoveX, int MagnitudeX);
	void moveY(int MoveY, int MagnitudeY);
	void setXandY(int NewX, int NewY);
	void playertracking(int px, int py);
;	Boss();
	~Boss();
};

