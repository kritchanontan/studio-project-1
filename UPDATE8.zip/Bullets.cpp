#include "Bullets.h"

void Bullets::setOldPosition(int x, int y)
{
    oldx = x;
    oldy = y;
}


void Bullets::setBulletSymbol(int x)
{
    if (x == 1)
        Symbol = '|';
    else
        Symbol = '-';
}

void Bullets::setBulletDirection(int x)
{
    bulletdirection = x;
}

int Bullets::getOldX()
{
    return oldx;
}

int Bullets::getOldy()
{
    return oldy;
}

char Bullets::getSymbol()
{
    return Symbol;
}

int Bullets::getBulletDIrection()
{
    return bulletdirection;
}

Bullets::~Bullets()
{
}