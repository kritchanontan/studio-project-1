#include "Alien.h"

Alien::Alien()
{
	character = (char)223;
	health = 1;
}
