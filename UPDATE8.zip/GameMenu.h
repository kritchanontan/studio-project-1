#pragma once

class GameMenu
{
public:
	void GameIntro();
};

