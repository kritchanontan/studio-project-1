#pragma once

class Entities
{
private:
	int x;
	int y;
protected:
	char character;
	int health;
public:
	Entities();
	void moveX(int MoveX, int MagnitudeX);
	void moveY(int MoveY, int MagnitudeY);
	char GetName() const;
	void setXandY(int NewX, int NewY);
	int GetX() const;
	int GetY() const;
	~Entities();
};

