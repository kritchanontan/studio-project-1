#include "Entities.h"
#include <string>

Entities::Entities()
{
	x = 10;
	y = 16;
	character = '?';
	health = 0;
}


void Entities::sethealth(int x)
{
	health = x;
}

void Entities::setName(char name)
{
	character = name;
}

void Entities::DecreaseHealth()
{
	health--;
}

char Entities::GetName() const
{
	return character;
}

int Entities::GetX() const
{
	return x;
}

int Entities::GetY() const
{
	return y;
}

int Entities::gethealth() const
{
	return health;
}

Entities::~Entities()
{
}