#include "GameEngine.h"
#include <Windows.h>
#include <iostream>
using namespace std;


void gotoXY(int x, int y) {
	COORD scrn;
	HANDLE hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	scrn.X = x; scrn.Y = y;
	SetConsoleCursorPosition(hConsoleOutput, scrn);
}

void GameEngine::ShowPlrHealth(int health) {
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hConsole, 7);
	gotoXY(1, 21);
	cout << (char)3 << " x " << health;
}

void GameEngine::BossKeys(bool k1, bool k2, bool k3, bool k4)
{
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hConsole, 7);
	gotoXY(22, 21);
	char key1 = (char)176;
	char key2 = (char)176;
	char key3 = (char)176;
	char key4 = (char)176;
	if (k1 == true) {
		key1 = (char)135;
	}
	if (k2 == true) {
		key2 = (char)159;
	}
	if (k3 == true) {
		key3 = (char)146;
	}
	if (k4 == true) {
		key4 = (char)168;
	}

	cout << "artifacts: " << key1 << ' ' << key2 << ' ' << key3 << ' ' << key4;
	gotoXY(36, 23);
}

void colour(WORD wAttrib)
{
	HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hStdout, wAttrib);
}

void GameEngine::GameClearScreen()
{
	HANDLE hOut;
	COORD Position;

	hOut = GetStdHandle(STD_OUTPUT_HANDLE);

	Position.X = 0;
	Position.Y = 0;
	SetConsoleCursorPosition(hOut, Position);
}

void GameEngine::GameCredits() {
	gotoXY(13, 7);
	cout << "DEVELOPED BY:";

	gotoXY(9, 9);
	cout << "TOON CHUAN ZHOU JERRYL";
	gotoXY(9, 10);
	cout << "RANDALL SOH ZHI YING";
	gotoXY(9, 11);
	cout << "HENG WEE HOW, ETHAN";
	gotoXY(9, 12);
	cout << "KRITCHANON TAN KIAN WEI";

	gotoXY(15, 14);
	cout << ">";
	while (true) {
		gotoXY(17, 14);  cout << "Back";
		system("pause>nul");
		if (GetAsyncKeyState(VK_RETURN) && 0x8000) {
			system("cls");
			GameIntro();
			break;
		}
	}
}

void GameEngine::GameHelp() {
	int menu_item = 0, x = 2;
	gotoXY(15, 7);
	cout << "HOW TO PLAY";
	bool running = true;
	gotoXY(9, 9);
	cout << "t";
	gotoXY(9, 10);
	cout << "e";
	gotoXY(9, 11);
	cout << "s";
	gotoXY(9, 12);
	cout << "t";

	gotoXY(2, 20);
	cout << "____";
	while (running) {
		gotoXY(2, 19);  cout << "Back";
		gotoXY(35, 19);  cout << "Next";
		system("pause>nul");

		if (GetAsyncKeyState(VK_LEFT) && x != 2) {
			gotoXY(x, 20); cout << "    ";
			x -= 33;
			gotoXY(x, 20); cout << "____";
			menu_item--;
			continue;
		}

		if (GetAsyncKeyState(VK_RIGHT) && x != 35) //down button pressed
		{
			gotoXY(x, 20); cout << "    ";
			x += 33;
			gotoXY(x, 20); cout << "____";
			menu_item++;
			continue;

		}

		if (GetAsyncKeyState(VK_RETURN) && 0x8000) {
			switch (menu_item) {
			case 0:
				system("cls");
				GameIntro();
				running = false;
				break;
			case 1:
				system("cls");
				GameHelp2();
				running = false;
				break;
			}
		}
	}
}

void GameEngine::GameHelp2() {
	int menu_item = 0;
	gotoXY(15, 7);
	cout << "HOW TO PLAY 2 ";
	bool running = true;
	gotoXY(9, 9);
	cout << "t";
	gotoXY(9, 10);
	cout << "e";
	gotoXY(9, 11);
	cout << "s";
	gotoXY(9, 12);
	cout << "t";

	gotoXY(2, 20);
	cout << "____";
	while (running) {
		gotoXY(2, 19);  cout << "Back";
		system("pause>nul");

		if (GetAsyncKeyState(VK_RETURN) && 0x8000) {
			switch (menu_item) {
			case 0:
				system("cls");
				GameHelp();
				running = false;
				break;
			}
		}
	}
}

void GameEngine::GameQuit() {
	system("cls");
	exit(0);
}

void GameEngine::GameScreenCursor(bool showFlag)
{
	HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);

	CONSOLE_CURSOR_INFO     cursorInfo;

	GetConsoleCursorInfo(out, &cursorInfo);
	cursorInfo.bVisible = showFlag; // set the cursor visibility
	SetConsoleCursorInfo(out, &cursorInfo);
}

void GameEngine::lockWindow()
{
	HWND consoleWindow = GetConsoleWindow();
	SetWindowLong(consoleWindow, GWL_STYLE, GetWindowLong(consoleWindow, GWL_STYLE) & ~WS_MAXIMIZEBOX & ~WS_SIZEBOX);
}

void GameEngine::WindowSize()
{
	SetConsoleTitle(TEXT("THE LEGEND OF ANGEVIN"));
	HWND console = GetConsoleWindow();
	RECT r;
	GetWindowRect(console, &r); //stores the console's current dimensions

	MoveWindow(console, r.left, r.top, 328, 405, TRUE); // 800 width, 100 height

}

void GameEngine::GameIntro()
{
	int menu_item = 0, x = 10;
	bool running = true;

	gotoXY(10, 8); 
	cout << "THE LEGEND OF ANGEVIN";

	gotoXY(15, 10); 
	cout << ">";

	while (running)
	{
		gotoXY(17, 10);  cout << "START";
		gotoXY(17, 12);  cout << "HOW TO PLAY";
		gotoXY(17, 14);  cout << "CREDITS";
		gotoXY(17, 16);  cout << "QUIT";
		system("pause>nul");

		if (GetAsyncKeyState(VK_DOWN) && x != 16) //down button pressed
		{
			gotoXY(15, x); cout << "  ";
			x += 2;
			gotoXY(15, x); cout << ">";
			menu_item++;
			continue;

		}

		if (GetAsyncKeyState(VK_UP) && x != 10) //up button pressed
		{
			gotoXY(15, x); cout << "  ";
			x -= 2;
			gotoXY(15, x); cout << ">";
			menu_item--;
			continue;
		}

		if (GetAsyncKeyState(VK_RETURN)) { // Enter key pressed

			switch (menu_item) {

				case 0: {
					running = false;
					break;
				}

				case 1: {
					system("cls");
					GameHelp();
					running = false;
					break;
				}

				case 2: {
					system("cls");
					GameCredits();
					running = false;
					break;
				}

				case 3: {
					system("cls");
					GameQuit();
					running = false;
					break;
				}

			}

		}

	}

	gotoXY(20, 21);
}


void GameEngine::GameDialogueIntro()
{
	gotoXY(0, 4);
	string GameStartsDialogue = "Once upon a time, there was a dragon\nnamed Angevin.\nAngevin lived in a town named\nTruffle Town.\nTruffle Town was a place full of nice\nand expensive truffles.\nIts geography was perfect for the growth of truffles.";
	int x = 0;
	while (GameStartsDialogue[x] != '\0')
	{
		cout << GameStartsDialogue[x];
		Sleep(50);
		x++;

		if (GetAsyncKeyState(VK_RETURN) & 0x8000) {
			system("cls");
			gotoXY(0, 4);
			cout << GameStartsDialogue;
			break;
		}
	};
	cout << endl << endl;
	system("pause");
}

void GameEngine::GamePause() {
	gotoXY(13, 10);
	cout << "Game is Paused" << endl;
	gotoXY(9, 11);
	cout << " Press ESC to continue";
	Sleep(500);
	while (true) {

		if (GetAsyncKeyState(VK_ESCAPE)) {
			Sleep(200);
			break;
		}
	}
	GameClearScreen();
}

void GameEngine::GameTextFont()
{
	HWND console = GetConsoleWindow();
	CONSOLE_FONT_INFOEX cfi;
	cfi.cbSize = sizeof(cfi);
	cfi.nFont = 0;
	cfi.dwFontSize.X = 0;                   // Width of each character in the font
	cfi.dwFontSize.Y = 24;                  // Height
	cfi.FontFamily = FF_DONTCARE;
	cfi.FontWeight = FW_NORMAL;
	wcscpy_s(cfi.FaceName, L"Consolas"); // Choose your font
	SetCurrentConsoleFontEx(GetStdHandle(STD_OUTPUT_HANDLE), FALSE, &cfi);
}