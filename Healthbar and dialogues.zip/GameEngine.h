#pragma once

class GameEngine
{
public:
	void GameClearScreen();
	void GameIntro();
	void GameHelp();
	void GameHelp2();
	void GameCredits();
	void GameDialogueIntro();
	void GamePause();
	void GameQuit();
	void ShowPlrHealth(int health);
	void BossKeys(bool k1, bool k2, bool k3, bool k4);
	void GameTextFont();
	void minibosshpbar(int hp);
	void bossText(int bossnumber);
	void PlayerKilledByEnemyDialogue();
	void PlayerKilledByMiniBossDialogue();
	void PlayerKilledByFinalBossDialogue();
	void GameScreenCursor(bool showFlag);
	void lockWindow();
	void WindowSize();
};

