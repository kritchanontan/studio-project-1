#pragma once
#include "Entities.h"

class Player : public Entities
{
public:
	Player();
};

