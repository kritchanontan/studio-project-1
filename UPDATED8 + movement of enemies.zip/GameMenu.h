#pragma once

class GameMenu
{
public:
	void GameClearScreen();
	void GameIntro();
	void GameDialogueIntro1();
	void GamePause();
	void GameCredits();
};

