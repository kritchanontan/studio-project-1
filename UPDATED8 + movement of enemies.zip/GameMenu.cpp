#include "GameMenu.h"
#include <Windows.h>
#include <iostream>
#include <cwchar>
using namespace std;

void gotoXY(int x, int y) {
	COORD scrn;
	HANDLE hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	scrn.X = x; scrn.Y = y;
	SetConsoleCursorPosition(hConsoleOutput, scrn);
}


void GameMenu::GameClearScreen()
{
	HANDLE hOut;
	COORD Position;

	hOut = GetStdHandle(STD_OUTPUT_HANDLE);

	Position.X = 0;
	Position.Y = 0;
	SetConsoleCursorPosition(hOut, Position);
}

void GameMenu::GameCredits() {
	gotoXY(13, 7);
	cout << "DEVELOPED BY:";

	gotoXY(9, 9);
	cout << "TOON CHUAN ZHOU JERRYL";
	gotoXY(9, 10);
	cout << "RANDALL SOH ZHI YING";
	gotoXY(9, 11);
	cout << "HENG WEE HOW, ETHAN";
	gotoXY(9, 12);
	cout << "KRITCHANON TAN KIAN WEI";

	gotoXY(15, 14);
	cout << ">";
	while (true) {
		gotoXY(17, 14);  cout << "Back";
		system("pause>nul");
		if (GetAsyncKeyState(VK_RETURN) && 0x8000) {
			system("cls");
			GameIntro();
			break;
		}
	}
}

void GameMenu::GameIntro()
{
	//CONSOLE_FONT_INFOEX cfi;
	//cfi.cbSize = sizeof(cfi);
	//cfi.nFont = 0;
	//cfi.dwFontSize.X = 0;                   // Width of each character in the font
	//cfi.dwFontSize.Y = 24;                  // Height
	//cfi.FontFamily = FF_DONTCARE;
	//cfi.FontWeight = FW_NORMAL;
	//wcscpy_s(cfi.FaceName, L"Consolas"); // Choose your font
	//SetCurrentConsoleFontEx(GetStdHandle(STD_OUTPUT_HANDLE), FALSE, &cfi);

	int menu_item = 0, x = 10;
	bool running = true;

	gotoXY(10, 8); 
	cout << "THE LEGEND OF ANGEVIN";

	gotoXY(15, 10); 
	cout << ">";

	while (running)
	{
		gotoXY(17, 10);  cout << "Start";
		gotoXY(17, 12);  cout << "Credits";

		system("pause>nul");

		if (GetAsyncKeyState(VK_DOWN) && x != 12) //down button pressed
		{
			gotoXY(15, x); cout << "  ";
			x += 2;
			gotoXY(15, x); cout << ">";
			menu_item++;
			continue;

		}

		if (GetAsyncKeyState(VK_UP) && x != 10) //up button pressed
		{
			gotoXY(15, x); cout << "  ";
			x -= 2;
			gotoXY(15, x); cout << ">";
			menu_item--;
			continue;
		}

		if (GetAsyncKeyState(VK_RETURN)) { // Enter key pressed

			switch (menu_item) {

			case 0: {
				running = false;
				break;
			}

			case 1: {
				system("cls");
				GameCredits();
				running = false;
				break;
			}

			}

		}

	}

	gotoXY(20, 21);
}


void GameMenu::GameDialogueIntro1()
{
	gotoXY(0, 4);
	string GameStartsDialogue = "Once upon a time, there was a dragon\nnamed Angevin.\nAngevin lived in a town named\nTruffle Town.\nTruffle Town was a place full of nice\nand expensive truffles.\nIts geography was perfect for the growth of truffles.";
	int x = 0;
	while (GameStartsDialogue[x] != '\0')
	{
		cout << GameStartsDialogue[x];
		Sleep(50);
		x++;

		if (GetAsyncKeyState(VK_RETURN) & 0x8000) {
			system("cls");
			gotoXY(0, 4);
			cout << GameStartsDialogue;
			break;
		}
	};
	cout << endl << endl;
	system("pause");
}

void GameMenu::GamePause() {
	gotoXY(13, 10);
	cout << "Game is Paused" << endl;
	gotoXY(9, 11);
	cout << " Press ESC to continue";
	Sleep(500);
	while (true) {

		if (GetAsyncKeyState(VK_ESCAPE)) {
			Sleep(200);
			break;
		}
	}
	GameClearScreen();
}