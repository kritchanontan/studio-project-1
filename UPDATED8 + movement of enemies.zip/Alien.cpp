#include "Alien.h"

Alien::Alien()
{
	character = 'E';
}
