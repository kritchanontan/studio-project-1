#include "Map.h"
#include <iostream>
#include <Windows.h>
using namespace std;

void Map::SetMapA1(bool temp) {
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 20 and j >= 0 and j <= 1)
				MapSize[i][j] = '#';
			if (i >= 0 and i <= 1 and j >= 0 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 20 and j >= 24 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 19 and j >= 26 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 18 and j >= 28 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 17 and j >= 30 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 16 and j >= 32 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 15 and j >= 34 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 14 and j >= 36 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 13 and j >= 38 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 12 and j == 40)
				MapSize[i][j] = '#';

			if (temp == true) {
				if (i >= 0 and i <= 20 and j >= 39 and j <= 40)
					MapSize[i][j] = '#';
				if (i >= 19 and i <= 20 and j >= 0 and j <= 40)
					MapSize[i][j] = '#';
			}
		}
	}
}

void Map::SetMapA2() {
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 1 and j >= 0 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 12 and i <= 20 and j >= 36 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 20 and j >= 0 and j <= 16)
				MapSize[i][j] = '#';
			if (i == 19 and j >= 0 and j <= 14)
				MapSize[i][j] = '#';
			if (i == 18 and j >= 0 and j <= 12)
				MapSize[i][j] = '#';
			if (i == 17 and j >= 0 and j <= 10)
				MapSize[i][j] = '#';
			if (i == 16 and j >= 0 and j <= 8)
				MapSize[i][j] = '#';
			if (i == 15 and j >= 0 and j <= 6)
				MapSize[i][j] = '#';
			if (i == 14 and j >= 0 and j <= 4)
				MapSize[i][j] = '#';
			if (i == 13 and j >= 0 and j <= 2)
				MapSize[i][j] = '#';
			if (i == 12 and j == 0)
				MapSize[i][j] = '#';
		}
	}
}

void Map::SetMapA3() {
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 1 and j >= 0 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 12 and i <= 20 and j >= 0 and j <= 4)
				MapSize[i][j] = '#';
			if (i >= 12 and i <= 20 and j >= 36 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 13 and i <= 20 and j >= 0 and j <= 4)
				MapSize[i][j] = '#';
			if (i >= 13 and i <= 20 and j >= 36 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 16 and i <= 20 and j >= 3 and j <= 14)
				MapSize[i][j] = '#';
			if (i >= 16 and i <= 20 and j >= 26 and j <= 37)
				MapSize[i][j] = '#';
		}
	}
}

void Map::SetMapA4() {
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 1 and j >= 0 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 17 and i <= 20 and j >= 26 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 18 and i <= 20 and j >= 0 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 18 and i <= 20 and j >= 15 and j <= 25)
				MapSize[i][j] = ' ';
			if (i == 12 and j >= 0 and j <= 1)
				MapSize[i][j] = '#';
			if (i == 17 and j >= 0 and j <= 11)
				MapSize[i][j] = '#';
			if (i == 16 and j >= 0 and j <= 9)
				MapSize[i][j] = '#';
			if (i == 15 and j >= 0 and j <= 7)
				MapSize[i][j] = '#';
			if (i == 14 and j >= 0 and j <= 5)
				MapSize[i][j] = '#';
			if (i == 13 and j >= 0 and j <= 3)
				MapSize[i][j] = '#';
		}
	}
}

void Map::SetMapA5(bool temp) {
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 1 and j >= 0 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 17 and i <= 20 and j >= 0 and j < 15)
				MapSize[i][j] = '#';
			if (i >= 2 and i <= 20 and j >= 39 and j <= 40)
				MapSize[i][j] = '#';
			if (temp == true) {
				if (i >= 0 and i <= 20 and j >= 0 and j <= 1)
					MapSize[i][j] = '#';
				if (i >= 19 and i <= 20 and j >= 0 and j <= 40)
					MapSize[i][j] = '#';
			}
		}
	}
}

void Map::SetMapB1() {
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 20 and j >= 0 and j <= 1)
				MapSize[i][j] = '#';
			if (i >= 19 and i <= 20 and j >= 9 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 0 and j >= 24 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 1 and j >= 26 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 2 and j >= 28 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 3 and j >= 30 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 4 and j >= 32 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 5 and j >= 34 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 6 and j >= 36 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 7 and j >= 38 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 8 and j == 40)
				MapSize[i][j] = '#';
		}
	}
}

void Map::SetMapB2() {
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 19 and i <= 20 and j >= 0 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 0 and i <= 1 and j >= 36 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 0 and j >= 0 and j <= 16)
				MapSize[i][j] = '#';
			if (i == 1 and j >= 0 and j <= 14)
				MapSize[i][j] = '#';
			if (i == 2 and j >= 0 and j <= 12)
				MapSize[i][j] = '#';
			if (i == 3 and j >= 0 and j <= 10)
				MapSize[i][j] = '#';
			if (i == 4 and j >= 0 and j <= 8)
				MapSize[i][j] = '#';
			if (i == 5 and j >= 0 and j <= 6)
				MapSize[i][j] = '#';
			if (i == 6 and j >= 0 and j <= 4)
				MapSize[i][j] = '#';
			if (i == 7 and j >= 0 and j <= 2)
				MapSize[i][j] = '#';
			if (i == 8 and j == 0)
				MapSize[i][j] = '#';
		}

	}
}

void Map::SetMapB3() {
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 1 and j >= 0 and j < 15)
				MapSize[i][j] = '#';
			if (i >= 0 and i <= 1 and j >= 26 and j <= 40)
				MapSize[i][j] = '#';

			if (i >= 19 and i <= 20 and j >= 0 and j < 15)
				MapSize[i][j] = '#';
			if (i >= 19 and i <= 20 and j >= 26 and j <= 40)
				MapSize[i][j] = '#';

			if (i >= 5 and i <= 7 and j >= 4 and j <= 8)
				MapSize[i][j] = '#';
			if (i >= 12 and i <= 14 and j >= 4 and j <= 8)
				MapSize[i][j] = '#';
			if (i >= 5 and i <= 7 and j > 17 and j < 23)
				MapSize[i][j] = '#';
			if (i >= 12 and i <= 14 and j > 17 and j < 23)
				MapSize[i][j] = '#';
			if (i >= 5 and i <= 7 and j > 31 and j <= 36)
				MapSize[i][j] = '#';
			if (i >= 12 and i <= 14 and j > 31 and j <= 36)
				MapSize[i][j] = '#';
		}
	}
}

void Map::SetMapB4() {
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 1 and j >= 0 and j <= 14)
				MapSize[i][j] = '#';
			if (i >= 19 and i <= 20 and j >= 0 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 0 and i <= 3 and j >= 26 and j <= 40)
				MapSize[i][j] = '#';
		}
	}
}

void Map::SetMapB5() {
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 19 and i <= 20 and j >= 0 and j <= 31)
				MapSize[i][j] = '#';
			if (i >= 0 and i <= 3 and j >= 0 and j < 15)
				MapSize[i][j] = '#';
			if (i >= 0 and i <= 20 and j >= 39 and j <= 40)
				MapSize[i][j] = '#';
		}
	}
}


void Map::SetMapC1() {
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 20 and j >= 0 and j <= 1)
				MapSize[i][j] = '#';
			if (i >= 0 and i <= 1 and j >= 9 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 2 and j >= 12 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 3 and j >= 15 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 4 and j >= 21 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 5 and j >= 25 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 6 and j >= 29 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 7 and j >= 33 and j <= 40)
				MapSize[i][j] = '#';
			//
			if (i == 13 and j >= 33 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 14 and j >= 29 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 15 and j >= 25 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 16 and j >= 21 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 17 and j >= 15 and j <= 40)
				MapSize[i][j] = '#';
			if (i == 18 and j >= 12 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 19 and i <= 20 and j >= 9 and j <= 40)
				MapSize[i][j] = '#';

		}
	}
}


void Map::SetMapC2()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = '#';
			if (i >= 8 and i <= 12 and j >= 0 and j <= 40)
				MapSize[i][j] = ' ';
		}
	}
}

void Map::SetMapC3Normal(bool temp)
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 1 and j >= 0 and j <= 14)
				MapSize[i][j] = '#';
			if (i >= 0 and i <= 1 and j >= 26 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 19 and i <= 20 and j >= 0 and j <= 14)
				MapSize[i][j] = '#';
			if (i >= 19 and i <= 20 and j >= 26 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 2 and i <= 7 and j >= 0 and j <= 4)
				MapSize[i][j] = '#';
			if (i >= 13 and i <= 18 and j >= 0 and j <= 4)
				MapSize[i][j] = '#';
			if (i >= 2 and i <= 7 and j >= 36 and j <= 40)
				MapSize[i][j] = '#';
			if (i >= 13 and i <= 18 and j >= 36 and j <= 40)
				MapSize[i][j] = '#';
			if (temp == true) {
				if (i >= 0 and i <= 1 and j >= 15 and j <= 25)
					MapSize[i][j] = '#';
				if (i >= 19 and i <= 20 and j >= 15 and j <= 25)
					MapSize[i][j] = '#';
				if (i >= 0 and i <= 20 and j >= 0 and j <= 4)
					MapSize[i][j] = '#';
				if (i >= 0 and i <= 20 and j >= 36 and j <= 40)
					MapSize[i][j] = '#';
			}
		}
	}
}

void Map::SetMapC4()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = '#';
			if (i >= 8 and i <= 12 and j >= 0 and j <= 40)
				MapSize[i][j] = ' ';
		}
	}
}

void Map::SetMapC5() {
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 20 and j >= 39 and j <= 40)
				MapSize[i][j] = '#';
			//
			if (i >= 0 and i <= 1 and j >= 0 and j <= 31)
				MapSize[i][j] = '#';
			if (i == 2 and j >= 0 and j <= 28)
				MapSize[i][j] = '#';
			if (i == 3 and j >= 0 and j <= 25)
				MapSize[i][j] = '#';
			if (i == 4 and j >= 0 and j <= 19)
				MapSize[i][j] = '#';
			if (i == 5 and j >= 0 and j <= 15)
				MapSize[i][j] = '#';
			if (i == 6 and j >= 0 and j <= 11)
				MapSize[i][j] = '#';
			if (i == 7 and j >= 0 and j <= 7)
				MapSize[i][j] = '#';
			//
			if (i == 13 and j >= 0 and j <= 7)
				MapSize[i][j] = '#';
			if (i == 14 and j >= 0 and j <= 11)
				MapSize[i][j] = '#';
			if (i == 15 and j >= 0 and j <= 15)
				MapSize[i][j] = '#';
			if (i == 16 and j >= 0 and j <= 19)
				MapSize[i][j] = '#';
			if (i == 17 and j >= 0 and j <= 25)
				MapSize[i][j] = '#';
			if (i == 18 and j >= 0 and j <= 28)
				MapSize[i][j] = '#';
			if (i >= 19 and i <= 20 and j >= 0 and j <= 31)
				MapSize[i][j] = '#';
		}
	}
}


void Map::SetMapD1() {
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 20 and j >= 0 and j <= 1)
				MapSize[i][j] = (char)177;
			if (i >= 0 and i <= 1 and j >= 9 and j <= 40)
				MapSize[i][j] = (char)177;
			if (i == 13 and j >= 39 and j <= 40)
				MapSize[i][j] = (char)177;
			if (i == 14 and j >= 38 and j <= 40)
				MapSize[i][j] = (char)177;
			if (i == 15 and j >= 36 and j <= 40)
				MapSize[i][j] = (char)177;
			if (i == 16 and j >= 32 and j <= 40)
				MapSize[i][j] = (char)177;
			if (i == 17 and j >= 28 and j <= 40)
				MapSize[i][j] = (char)177;
			if (i == 18 and j >= 27 and j <= 40)
				MapSize[i][j] = (char)177;
			if (i >= 19 and i <= 20 and j >= 25 and j <= 40)
				MapSize[i][j] = (char)177;
		}
	}
}


void Map::SetMapD2() {
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 1 and j >= 0 and j <= 40)
				MapSize[i][j] = (char)177;
			if (i >= 19 and i <= 20 and j >= 25 and j <= 40)
				MapSize[i][j] = (char)177;
			//
			if (i >= 19 and i <= 20 and j >= 0 and j <= 15)
				MapSize[i][j] = (char)177;
			if (i == 18 and j >= 0 and j <= 13)
				MapSize[i][j] = (char)177;
			if (i == 17 and j >= 0 and j <= 12)
				MapSize[i][j] = (char)177;
			if (i == 16 and j >= 0 and j <= 8)
				MapSize[i][j] = (char)177;
			if (i == 15 and j >= 0 and j <= 4)
				MapSize[i][j] = (char)177;
			if (i == 14 and j >= 0 and j <= 2)
				MapSize[i][j] = (char)177;
			if (i == 13 and j >= 0 and j <= 1)
				MapSize[i][j] = (char)177;

		}
	}
}

void Map::SetMapD3() {
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 1 and j >= 0 and j < 15)
				MapSize[i][j] = '#';
			if (i >= 0 and i <= 1 and j >= 26 and j <= 40)
				MapSize[i][j] = '#';

			if (i >= 19 and i <= 20 and j >= 0 and j < 15)
				MapSize[i][j] = '#';
			if (i >= 19 and i <= 20 and j >= 26 and j <= 40)
				MapSize[i][j] = '#';

			if (i >= 5 and i <= 7 and j >= 4 and j <= 8)
				MapSize[i][j] = '#';
			if (i >= 12 and i <= 14 and j >= 4 and j <= 8)
				MapSize[i][j] = '#';
			if (i >= 5 and i <= 7 and j > 17 and j < 23)
				MapSize[i][j] = '#';
			if (i >= 12 and i <= 14 and j > 17 and j < 23)
				MapSize[i][j] = '#';
			if (i >= 5 and i <= 7 and j > 31 and j <= 36)
				MapSize[i][j] = '#';
			if (i >= 12 and i <= 14 and j > 31 and j <= 36)
				MapSize[i][j] = '#';
		}
	}
}

void Map::SetMapD4()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 1 and j >= 0 and j <= 40)
				MapSize[i][j] = (char)176;
			if (i >= 19 and i <= 20 and j >= 0 and j <= 4)
				MapSize[i][j] = (char)176;
			if (i >= 13 and i <= 20 and j >= 26 and j <= 40)
				MapSize[i][j] = (char)176;
		}
	}
}

void Map::SetMapD5()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 0 and i <= 1 and j >= 0 and j <= 31)
				MapSize[i][j] = (char)176;
			if (i >= 0 and i <= 20 and j >= 39 and j <= 40)
				MapSize[i][j] = (char)176;
			if (i >= 13 and i <= 20 and j >= 0 and j < 15)
				MapSize[i][j] = (char)176;
		}
	}
}

void Map::SetMapE1(bool temp)
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';
			if (i >= 19 and i <= 20 and j >= 0 and j <= 40) {
				MapSize[i][j] = (char)177;
			}
			if (i >= 0 and i < 20 and j >= 0 and j < 2) {
				MapSize[i][j] = (char)177;
			}

			if (i >= 0 and i <= 7 and j >= 25 and j <= 40) {
				MapSize[i][j] = (char)177;
			}

			if (temp == true) {
				if (i >= 0 and i <= 1 and j >= 2 and j <= 24) {
					MapSize[i][j] = (char)177;
				}
				if (i >= 0 and i <= 20 and j >= 39 and j <= 40) {
					MapSize[i][j] = (char)177;
				}
			}

			if (i == 2 and j >= 25 and j <= 26) {
				MapSize[i][j] = ' ';
			}

			if (i == 3 and j >= 25 and j <= 27) {
				MapSize[i][j] = ' ';
			}
			if (i == 4 and j >= 25 and j <= 31) {
				MapSize[i][j] = ' ';
			}
			if (i == 5 and j >= 25 and j <= 35) {
				MapSize[i][j] = ' ';
			}
			if (i == 6 and j >= 25 and j <= 37) {
				MapSize[i][j] = ' ';
			}
			if (i == 7 and j >= 25 and j <= 38) {
				MapSize[i][j] = ' ';
			}
		}
	}
}

void Map::SetMapE2()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';

			if (i >= 19 and i <= 20 and j >= 0 and j <= 40) {
				MapSize[i][j] = (char)177;
			}


			if (i >= 0 and i <= 1 and j >= 0 and j <= 40) {
				MapSize[i][j] = (char)177;
			}

			if (i == 2 and j >= 0 and j <= 40) {
				MapSize[i][j] = (char)177;
				for (int j = 14; j <= 26; j++) {
					MapSize[i][j] = ' ';
				}
			}

			if (i == 3 and j >= 0 and j <= 40) {
				MapSize[i][j] = (char)177;
				for (int j = 13; j <= 27; j++) {
					MapSize[i][j] = ' ';
				}
			}

			if (i == 4 and j >= 0 and j <= 40) {
				MapSize[i][j] = (char)177;
				for (int j = 9; j <= 31; j++) {
					MapSize[i][j] = ' ';
				}
			}

			if (i == 5 and j >= 0 and j <= 40) {
				MapSize[i][j] = (char)177;
				for (int j = 5; j <= 35; j++) {
					MapSize[i][j] = ' ';
				}
			}

			if (i == 6 and j >= 0 and j <= 40) {
				MapSize[i][j] = (char)177;
				for (int j = 3; j <= 37; j++) {
					MapSize[i][j] = ' ';
				}
			}

			if (i == 7 and j >= 0 and j <= 40) {
				MapSize[i][j] = (char)177;
				for (int j = 2; j <= 38; j++) {
					MapSize[i][j] = ' ';
				}
			}

			for (int i = 0; i < 9; i++) {
				for (int j = 16; j < 25; j++) {
					MapSize[i][j] = ' ';
				}
			}
		}
		cout << endl;
	}
}

void Map::SetMapE3()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';

			if (i >= 19 and i <= 20 and j >= 0 and j <= 40) {
				MapSize[i][j] = '#';
			}
			if (i >= 0 and i < 5 and j >= 0 and j <= 40) {
				MapSize[i][j] = '#';
			}
			for (int i = 0; i < 9; i++) {
				for (int j = 15; j <= 25; j++) {
					MapSize[i][j] = ' ';
				}
			}

			if (i >= 5 and i < 8 and j >= 0 and j <= 40) {
				MapSize[i][j] = '#';
			}

			for (int i = 4; i <= 8; i++) {
				for (int j = 5; j <= 35; j++) {
					MapSize[i][j] = ' ';
				}
			}

			for (int i = 15; i < 25; i++) {
				MapSize[0][i] = ' ';
			}
		}
		cout << endl;
	}
}

void Map::SetMapE4()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';

			if (i >= 19 and i <= 20 and j >= 0 and j <= 40) {
				MapSize[i][j] = (char)176;
			}

			if (i >= 0 and i < 8 and j >= 0 and j <= 40) {
				MapSize[i][j] = (char)176;
			}

			for (int i = 0; i <= 8; i++) {
				for (int j = 5; j <= 25; j++) {
					MapSize[i][j] = ' ';
				}
			}
		}
	}
}


void Map::SetMapE5(bool temp)
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {
			MapSize[i][j] = ' ';

			if (i >= 19 and i <= 20 and j >= 0 and j <= 40) {
				MapSize[i][j] = (char)176;
			}

			if (i >= 0 and i < 8 and j >= 0 and j < 15) {
				MapSize[i][j] = (char)176;
			}

			if (i >= 0 and i < 20 and j > 38 and j <= 40) {
				MapSize[i][j] = (char)176;
			}
			if (temp == true) {
				if (i >= 0 and i <= 1 and j > 0 and j <= 40) {
					MapSize[i][j] = (char)176;
				}
				if (i >= 0 and i < 20 and j >= 0 and j <= 1) {
					MapSize[i][j] = (char)176;
				}
			}
		}
	}
}


//Map1
void Map::SpawnMap()
{
	for (int i = 0; i <= 20; i++) {
		for (int j = 0; j <= 40; j++) {

			if (MapSize[i][j] == (char)176)
			{
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_BLUE | FOREGROUND_INTENSITY);
			}
			else if (MapSize[i][j] == (char)177)
			{
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN | FOREGROUND_INTENSITY);
			}
			else if (MapSize[i][j] == (char)254)
			{
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_RED | FOREGROUND_INTENSITY);
			}
			else if (MapSize[i][j] == '#')
			{
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_RED | FOREGROUND_INTENSITY);
			}
			else
			{
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_BLUE | FOREGROUND_GREEN | FOREGROUND_RED);
			}
			cout << MapSize[i][j];
		}
		cout << endl;
	}
}


void Map::removebullets(int x, int y)
{
	MapSize[y][x] = ' ';
}

bool Map::CollisionX(int PosX, int PosY, int MagnitudeX)
{
	if (MagnitudeX == -1) {
		if (MapSize[PosY][PosX - 1] == '#' or MapSize[PosY][PosX - 1] == (char)176 or MapSize[PosY][PosX - 1] == (char)205 or MapSize[PosY][PosX - 1] == (char)177) {
			return true;
		}
	}
	if (MagnitudeX == 1) {
		if (MapSize[PosY][PosX + 1] == '#' or MapSize[PosY][PosX + 1] == (char)176 or MapSize[PosY][PosX + 1] == (char)205 or MapSize[PosY][PosX + 1] == (char)177) {
			return true;
		}
	}
	return false;
}

bool Map::CollisionY(int PosX, int PosY, int MagnitudeY)
{
	if (MagnitudeY == -1) {
		if (MapSize[PosY - 1][PosX] == '#' or MapSize[PosY - 1][PosX] == (char)176 or MapSize[PosY - 1][PosX] == (char)205 or MapSize[PosY - 1][PosX] == (char)177) {
			return true;
		}
	}
	if (MagnitudeY == 1) {
		if (MapSize[PosY + 1][PosX] == '#' or MapSize[PosY + 1][PosX] == (char)176 or MapSize[PosY + 1][PosX] == (char)205 or MapSize[PosY + 1][PosX] == (char)177) {
			return true;
		}
	}
	return false;
}

bool Map::CollisionPlayerandEnemies(int PlayerX, int PlayerY, int EnemyX, int EnemyY)
{
	if (PlayerX == EnemyX and PlayerY == EnemyY) {
		return true;
	}
	return false;
}

void Map::DrawEntities(int PosX, int PosY, int MagnitudeX, int MagnitudeY, char name)
{
	// Spawn Entities
	MapSize[PosY][PosX] = name;

	// Left Arrow Movement
	if (MagnitudeX == -1 and (MapSize[PosY][PosX + 1] == (char)219 or MapSize[PosY][PosX + 1] == '|' or MapSize[PosY][PosX + 1] == (char)196)) {
		MapSize[PosY][PosX + 1] = ' ';
	}

	// Right Arrow Movement
	if (MagnitudeX == 1 and (MapSize[PosY][PosX - 1] == (char)219 or MapSize[PosY][PosX - 1] == '|' or MapSize[PosY][PosX - 1] == (char)196)) {
		MapSize[PosY][PosX - 1] = ' ';
	}

	// Up Arrow Movement
	if (MagnitudeY == -1 and (MapSize[PosY + 1][PosX] == (char)219 or MapSize[PosY + 1][PosX] == '|' or MapSize[PosY + 1][PosX] == (char)196)) {
		MapSize[PosY + 1][PosX] = ' ';
	}

	// Down Arrow Movement
	if (MagnitudeY == 1 and (MapSize[PosY - 1][PosX] == (char)219 or MapSize[PosY - 1][PosX] == '|' or MapSize[PosY - 1][PosX] == (char)196)) {
		MapSize[PosY - 1][PosX] = ' ';
	}

	//Up and right arrow
	if (MagnitudeX == 1 and MagnitudeY == -1 and MapSize[PosY + 1][PosX - 1] == (char)219) {
		MapSize[PosY + 1][PosX - 1] = ' ';
	}

	// Down and left arrow
	if (MagnitudeX == -1 and MagnitudeY == 1 and MapSize[PosY - 1][PosX + 1] == (char)219) {
		MapSize[PosY - 1][PosX + 1] = ' ';
	}

	// down and right arrow
	if (MagnitudeX == 1 and MagnitudeY == 1 and MapSize[PosY - 1][PosX - 1] == (char)219) {
		MapSize[PosY - 1][PosX - 1] = ' ';
	}

	// Up and left arrow
	if (MagnitudeX == -1 and MagnitudeY == -1 and MapSize[PosY + 1][PosX + 1] == (char)219) {
		MapSize[PosY + 1][PosX + 1] = ' ';
	}


	// BOT Movement
	// Left Movement
	if (MagnitudeX == -1 and MapSize[PosY][PosX + 1] == 'E' or MapSize[PosY][PosX + 1] == 'B') {
		MapSize[PosY][PosX + 1] = ' ';
	}

	// Right Movement
	if (MagnitudeX == 1 and MapSize[PosY][PosX - 1] == 'E' or MapSize[PosY][PosX - 1] == 'B') {
		MapSize[PosY][PosX - 1] = ' ';
	}

	// Up Movement
	if (MagnitudeY == -1 and MapSize[PosY + 1][PosX] == 'E' or MapSize[PosY + 1][PosX] == 'B') {
		MapSize[PosY + 1][PosX] = ' ';
	}

	// Down Movement
	if (MagnitudeY == 1 and MapSize[PosY - 1][PosX] == 'E' or MapSize[PosY - 1][PosX] == 'B') {
		MapSize[PosY - 1][PosX] = ' ';
	}
	//Up and right Movement
	if (MagnitudeX == 1 and MagnitudeY == -1 and MapSize[PosY + 1][PosX - 1] == 'E' or MapSize[PosY + 1][PosX - 1] == 'B') {
		MapSize[PosY + 1][PosX - 1] = ' ';
	}

	// Down and left Movement
	if (MagnitudeX == -1 and MagnitudeY == 1 and MapSize[PosY - 1][PosX + 1] == 'E' or MapSize[PosY - 1][PosX + 1] == 'B') {
		MapSize[PosY - 1][PosX + 1] = ' ';
	}

	// down and right arrow
	if (MagnitudeX == 1 and MagnitudeY == 1 and MapSize[PosY - 1][PosX - 1] == 'E' or MapSize[PosY - 1][PosX - 1] == 'B') {
		MapSize[PosY - 1][PosX - 1] = ' ';
	}

	// Up and left arrow
	if (MagnitudeX == -1 and MagnitudeY == -1 and MapSize[PosY + 1][PosX + 1] == 'E' or MapSize[PosY + 1][PosX + 1] == 'B') {
		MapSize[PosY + 1][PosX + 1] = ' ';
	}
}



int Map::BulletCollisionX(int PosX, int PosY, int MagnitudeX, char name)
{
	if (MagnitudeX == -1) {
		if ((MapSize[PosY][PosX - 1] == '#') || (PosX - 1 == 0) || (MapSize[PosY][PosX - 1] == (char)176) || (MapSize[PosY][PosX - 1] == (char)177)) {
			return 1; //if hit border
		}
		else if ((MapSize[PosY][PosX - 1] == (char)232) || (MapSize[PosY][PosX - 1] == (char)234) || (MapSize[PosY][PosX - 1] == 'E') || (MapSize[PosY][PosX - 1] == 'B')) {
			return 2; //if hit an enemy
		}
		else if (MapSize[PosY][PosX - 1] == (char)219) {
			return 3; //if hit player
		}
	}
	if (MagnitudeX == 1) {
		if ((MapSize[PosY][PosX + 1] == '#') || (MapSize[PosY][PosX + 1] == (char)176) || (MapSize[PosY][PosX + 1] == (char)177)) {
			return 1;
		}
		else if ((MapSize[PosY][PosX + 1] == (char)232) || (MapSize[PosY][PosX + 1] == (char)234) || (MapSize[PosY][PosX + 1] == 'E') || (MapSize[PosY][PosX + 1] == 'B')) {
			return 2;
		}
		else if (MapSize[PosY][PosX + 1] == (char)219) {
			return 3;
		}
	}
	//add bullet collision for enemies and players
	return 0;
}

bool Map::TriggerWallBossandPlayer(int y, int x, string mapname)
{
	if (mapname == "A1") {
		if (x >= 2 and x <= 16 and y >= 2 and y <= 9) {
			return true;
		}
	}
	if (mapname == "A5") {
		if (x >= 24 and x <= 38 and y >= 2 and y <= 9) {
			return true;
		}
	}
	if (mapname == "E1") {
		if (x >= 2 and x <= 16 and y >= 10 and y <= 18) {
			return true;
		}
	}
	if (mapname == "E5") {
		if (x >= 24 and x <= 38 and y >= 10 and y <= 18) {
			return true;
		}
	}

	if (mapname == "C3Normal") {
		if (x >= 15 and x <= 25 and y >= 5 and y <= 15) {
			return true;
		}
	}
	return false;
}


int Map::CheckMap(int y, int x)
{
	if ((MapSize[y][x] == '#') || (MapSize[y][x] == (char)176) || (MapSize[y][x] == (char)177) || (MapSize[y][x] == (char)205)) {
		return 1;
	}
	else if ((MapSize[y][x] == (char)219) || (MapSize[y][x] == 'E')) {
		return 2;
	}
	else {
		return 0;
	}
}

int Map::BulletCollisionY(int PosX, int PosY, int MagnitudeY, char name)
{
	if (MagnitudeY == -1) {
		if ((MapSize[PosY - 1][PosX] == '#') || (PosY - 1 == 0) || (MapSize[PosY - 1][PosX] == (char)176) || (MapSize[PosY - 1][PosX] == (char)177)) {
			return 1;
		}
		else if ((MapSize[PosY - 1][PosX] == (char)232) || (MapSize[PosY - 1][PosX] == (char)234) || (MapSize[PosY - 1][PosX] == 'E') || (MapSize[PosY - 1][PosX] == 'B')) {
			return 2;
		}
		else if (MapSize[PosY - 1][PosX] == (char)219) {
			return 3;
		}
	}
	if (MagnitudeY == 1) {
		if ((MapSize[PosY + 1][PosX] == '#') || (MapSize[PosY + 1][PosX] == (char)176) || (MapSize[PosY + 1][PosX] == (char)177)) {
			return 1;
		}
		else if ((MapSize[PosY + 1][PosX] == (char)232) || (MapSize[PosY + 1][PosX] == (char)234) || (MapSize[PosY + 1][PosX] == 'E') || (MapSize[PosY + 1][PosX] == 'B')) {
			return 2;
		}
		else if (MapSize[PosY + 1][PosX] == (char)219) {
			return 3;
		}
	}
	//add bullet collision for enemies and players
	return 0;
}
