#include "Bullets.h"

void Bullets::setOldPosition(int x, int y)
{
    oldx = x;
    oldy = y;
}

void Bullets::setNewPosition(int x, int y)
{
    newx = x;
    newy = y;
}

void Bullets::setBulletSymbol(int x)
{
    if (x == 1)
        Symbol = '|';
    else
        Symbol = '-';
}

void Bullets::setBulletDirection(int x)
{

}

int Bullets::getOldX()
{
    return oldx;
}

int Bullets::getOldy()
{
    return oldy;
}

int Bullets::getNewX()
{
    return newx;
}

int Bullets::getNewY()
{
    return newy;
}

char Bullets::getSymbol()
{
    return Symbol;
}
