#include "GameMenu.h"
#include <Windows.h>
#include <iostream>
using namespace std;

void gotoXY(int x, int y) {
	COORD scrn;
	HANDLE hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	scrn.X = x; scrn.Y = y;
	SetConsoleCursorPosition(hConsoleOutput, scrn);
}

void GameMenu::GameIntro()
{
	int menu_item = 0, x = 9;
	bool running = true;

	gotoXY(12, 7); 
	cout << "NAME OF GAME";

	gotoXY(12, 9); 
	cout << "->";

	while (running)
	{
		gotoXY(14, 9);  cout << "Start";
		gotoXY(14, 10);  cout << "Quit";

		system("pause>nul"); // the >nul bit causes it the print no message

		if (GetAsyncKeyState(VK_DOWN) && x != 10) //down button pressed
		{
			gotoXY(12, x); cout << "  ";
			x++;
			gotoXY(12, x); cout << "->";
			menu_item++;
			continue;

		}

		if (GetAsyncKeyState(VK_UP) && x != 9) //up button pressed
		{
			gotoXY(12, x); cout << "  ";
			x--;
			gotoXY(12, x); cout << "->";
			menu_item--;
			continue;
		}

		if (GetAsyncKeyState(VK_RETURN)) { // Enter key pressed

			switch (menu_item) {

			case 0: {
				running = false;
				break;
			}

			case 1: {
				running = false;
				break;
			}

			}

		}

	}

	gotoXY(20, 21);
}
